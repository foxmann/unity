﻿using UnityEngine;
using System.Collections;

public class CsEnemyMine : MonoBehaviour {
	
	public Transform missile;		// 프리팹 
	public Transform expSmall;		// 작은 불꽃 
	public AudioClip sndMine;		// 기뢰 폭파 사운드 
	
	Transform spaceShip;			// 우주선 
	
	int speed = 2;					// 이동 속도 
	float delay = 2f;				// 미사일 발사 지연 시간 
	
	//--------------------------
	// Game 초기화 
	//--------------------------
	void Start () {
		// 우주선 찾기 
		spaceShip = GameObject.Find("우주선").transform;
		
		// 우주선 방향으로 회전 
		transform.LookAt(spaceShip);
	}
	
	//--------------------------
	// Game Loop
	//--------------------------
	void Update () {
		float amtMove = speed * Time.smoothDeltaTime;
		transform.Translate(Vector3.forward * amtMove);
		
		delay -= Time.deltaTime;
		if (delay <= 0) {
			FireMissile();	
		}
	}
	
	//--------------------------
	// Missile 발사 
	//--------------------------
	void FireMissile () {
		// 우주선 방향으로 회전 
		transform.LookAt(spaceShip);
		
		// 기뢰의 회전각
		Quaternion rotation = transform.rotation;
		Vector3 ang = transform.eulerAngles;
		
		// 미사일의 회전각 
		for (int i = -2; i <= 2; i++) {
			float y = ang.y + i * 15;	// 미사일의 회전각 
			
			rotation.eulerAngles = new Vector3(ang.x, y, ang.z);		
			Instantiate(missile, transform.position, rotation);
		}
		
		// 작은 불꽃 표시 
		Instantiate(expSmall, transform.position, Quaternion.identity);
		Destroy (gameObject);	// 기뢰 제거 
	}
	
	//--------------------------
	// 기뢰 파괴 - 외부 호출
	//--------------------------
	void DestroySelf () {
		AudioSource.PlayClipAtPoint(sndMine, transform.position);
		Instantiate(expSmall, transform.position, Quaternion.identity);
		
		CsManager.mineCnt++;
		CsManager.score += 1000;
		
		Destroy(gameObject);
	}
}

