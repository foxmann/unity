using UnityEngine;
using System.Collections;

public class CsEnemy : MonoBehaviour {
	
	public Transform enemyMine;			// 기뢰 - 프리팹 
	public Transform expSmall;			// 폭파 불꽃 작은 것 
	public Transform expBig;			// 폭파 불꽃 큰 것 
	
	public AudioClip sndAttacked;		// 레이저 피격음 
	public AudioClip sndDestroy;		// 적기 폭파음 
	
	Transform spPoint; 					// Spawn Point
	
	int speed = 2;						// 이동 속도 
	int dir = 0;						// 이동 방향 (0:아래, 1:오른쪽, -1:왼쪽)
	int shield = 80;					// 보호막 
	
	//--------------------------
	// 게임 초기화 
	//--------------------------
	void Start () {
		spPoint = transform.Find("spPoint");	
		
		// 적기가 화면 아래를 향하도록 회전 
		transform.eulerAngles = new Vector3(0, 180, 0);
	}
	
	//--------------------------
	// Game Loop
	//--------------------------
	void Update () {
		if (dir == 0) {		// 아래로 이동	
			EnterEnemy();
		} else {	
			MoveEnemy();	// 좌우로 이동 
		}	

		// 기뢰 발사 
		if (dir != 0 && Random.Range(0, 1000) > 990) {	
			Instantiate (enemyMine, spPoint.position, spPoint.rotation);	
		}	
	}
	
	//--------------------------
	// 적기 등장 - 아래로 이동 
	//--------------------------
	void EnterEnemy () {
		// 화면 아래로 이동 
		float amtMove = speed * Time.smoothDeltaTime;
		transform.Translate(Vector3.forward * amtMove);
		
		// 적기의 위치 계산 
		Vector3 view = Camera.main.WorldToScreenPoint(transform.position);
		
		// 적기가 완전히 보이게 되면 좌우 이동 방향 설정 
		if (view.y < Screen.height * 0.82f) {
			dir = (Random.Range (0, 2) == 0) ? -1 : 1;
		}
	}
	
	//--------------------------
	// 적기 이동 - 좌우로 이동 
	//--------------------------
	void MoveEnemy () {
		// 좌우로 이동 
		float amtMove = speed * Time.smoothDeltaTime;
		transform.Translate(Vector3.right * amtMove * dir, Space.World);
		
		// 화면 가장자리에 접근했는지 조사 
		Vector3 view = Camera.main.WorldToScreenPoint(transform.position);
		int width = Screen.width;
		
		// 화면 가장자리에 접근하면 이동 방향 반전 
		if (view.x < width * 0.1f || view.x > width * 0.75f) {
			dir = -dir;	
		}
	}
	
	//--------------------------
	// 레이저에 피격 - 외부 호출 
	//--------------------------
	void Attacked (Vector3 pos) {
		shield--;
		// 레이저 피격음 
		AudioSource.PlayClipAtPoint(sndAttacked, pos);
		
		if (shield >= 0) {					// 작은 불꽃 표시 
			Instantiate (expSmall, pos, Quaternion.identity);
			CsManager.score += 100;			// 적기 명중 
		} else {							// 적기 파괴 
			StartCoroutine("DestroySelf");	
		}
	}
	
	//---------------------------
	// 적기 파괴 
	//---------------------------
	IEnumerator DestroySelf () {
		// 적기 폭파음 
		AudioSource.PlayClipAtPoint(sndDestroy, transform.position);
		
		// 시간차를 두고 여기저기에 큰 폭파 불꽃 표시 
		for (int i = 1; i <= 10; i++) {
			Vector3 pos = transform.position;
			pos.x = Random.Range (pos.x - 1, pos.x + 1f);
			pos.z = Random.Range (pos.z - 1, pos.z + 1f);
			
			Instantiate(expBig, pos, Quaternion.identity);
			
			yield return new WaitForSeconds(0.05f);
		}
		
		// 적기 파괴 후 처리 - GameManager에 통지(보류)
		CsManager.state = CsManager.STATE.DESTROY;
		
		// 적기 제거 
		Destroy(gameObject);
	}
}

