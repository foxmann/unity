using UnityEngine;
using System.Collections;

public class CsBonus : MonoBehaviour {

	float speed;
	
	//--------------------------
	// 게임 초기화 
	//--------------------------
	void Start () {
		speed = Random.Range(2.5f, 4);
	}
	
	//--------------------------
	// Game Loop
	//--------------------------
	void Update () {
		Vector3 dir = Vector3.zero;		// 이동 방향 및 거리 
		
		dir.x = -speed * CsShip.dir.x;
		dir.z = -speed * CsShip.dir.y;
		
		transform.Translate(dir * Time.smoothDeltaTime);
		
		// 화면을 벗어난 오브젝트 제거 
		Vector3 pos = transform.position;
		if (Mathf.Abs(pos.x) > 12 || Mathf.Abs(pos.z) > 8) {
			Destroy(gameObject);	
		}
	}
	
	//--------------------------
	// Bonus 충돌 처리 - 외부 호출 
	//--------------------------
	void GetBonusItem () {
		// Bonus Item 번호 구하기 
		int n = int.Parse(transform.tag.Substring(5, 1));
		CsManager.bonusNum = n;
			
		// 현재 상태 보존 후 상태 설정 
		CsManager.lastState = CsManager.state;	
		CsManager.state = CsManager.STATE.BONUS;
		
		Destroy(gameObject);	// Bonus Item 제거 
	}
}
