using UnityEngine;
using System.Collections;

public class CsLaser : MonoBehaviour {
	
	int speed = 15;					// 이동 속도 

	//--------------------------
	// 게임 초기화 
	//--------------------------
	void Start () {
		Destroy (gameObject, 1.5f);		// 발사 1.5초 후 레이저 자동 제거 
	}
	
	//--------------------------
	// 이동 
	//--------------------------
	void Update () {
		float amtMove = speed * Time.smoothDeltaTime;
		transform.Translate(Vector3.forward * amtMove);
	}
	
	//--------------------------
	// 충돌 판정 
	//--------------------------
	void OnTriggerEnter (Collider coll) {
		switch (coll.tag) {
		case "SPACESHIP" :
			return;
		case "MINE" :
			coll.SendMessage("DestroySelf", SendMessageOptions.DontRequireReceiver);
			
			CsManager.score += 1000;		
			CsManager.mineCnt++;				
			break;
		case "ASTEROID" :	// 운석 
			coll.SendMessage("Attacked", transform.position, SendMessageOptions.DontRequireReceiver);
			break;
		case "ENEMY" :		// 적기 
			// 적기의 부모 찾기 
			GameObject obj = coll.transform.root.gameObject;
			
			// 부모에게 충돌 통지 
			obj.SendMessage("Attacked", transform.position, SendMessageOptions.DontRequireReceiver);
			break;
		} 
		
		// Bonus 아이템과의 충돌 
		if (coll.tag.Contains("BONUS")) {
			coll.SendMessage("GetBonusItem", SendMessageOptions.DontRequireReceiver);
		}
		
		Destroy(gameObject);			// 레이저 제거 
	}
}
