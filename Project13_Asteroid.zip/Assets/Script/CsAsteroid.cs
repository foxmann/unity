using UnityEngine;
using System.Collections;

public class CsAsteroid : MonoBehaviour {
	
	public Transform expSmall;			// 폭파 불꽃 작은 것 
	public Transform expBig;			// 폭파 불꽃 큰 것 
	public Transform bonus;				// Bonus 아이템 
	
	public AudioClip sndAttacked;		// 레이저 피격음 
	public AudioClip sndDestroy;		// 운석 폭파음 
	
	float speed;						// 이동 속도 
	int shield;							// 보호막(강도) 
	
	Vector3 dir = Vector3.zero;			// 이동 방향 및 거리 
	Vector3 rot = Vector3.zero;			// 회전 방향 

	//--------------------------
	// 게임 초기화 
	//--------------------------
	void Start () {
		SetAsteroid();
	}
	
	//--------------------------
	// Game Loop
	//--------------------------
	void Update () {
		// 이동 
		dir.x = -speed * CsShip.dir.x;
		dir.z = -speed * CsShip.dir.y;
		
		transform.Translate(dir * Time.smoothDeltaTime, Space.World);
		
		// 회전 
		transform.Rotate(rot * Time.smoothDeltaTime);
		
		// 화면을 벗어난 운석 제거 
		Vector3 pos = transform.position;
		if (Mathf.Abs(pos.x) > 12 || Mathf.Abs(pos.z) > 8) {
			Destroy(gameObject);	
		}
	}
	
	//--------------------------
	// 레이저에 피격 - 외부 호출 
	//--------------------------
	void Attacked (Vector3 pos) {
		shield--;
		// 레이저 피격음 
		AudioSource.PlayClipAtPoint(sndAttacked, pos);
		
		if (shield >= 0) {				// 작은 불꽃 표시 
			Instantiate(expSmall, pos, Quaternion.identity);	
			CsManager.score += 100;		// 운석 명중 
		} else {						// 운석 파괴 
			MakeBonus();				// Bonus 아이템 만들기 	
			DestroySelf();	
		}
	}
	
	//---------------------------
	// 운석 파괴 
	//---------------------------
	void DestroySelf () {
		// 운석 폭파음 
		AudioSource.PlayClipAtPoint(sndDestroy, transform.position);
		
		// 큰 폭파 불꽃 표시 
		Instantiate(expBig, transform.position, Quaternion.identity);
		
		CsManager.score += 1000;	// 운석 파괴 
		CsManager.asterCnt++;		// 파괴한 운석 수 
		Destroy(gameObject);
	}
	
	//---------------------------
	// Bonus Item 만들기 
	//---------------------------
	void MakeBonus () {
		if (Random.Range(0, 100) < 90) return;
		
		// Bonus 아이템 색깔 
		Color[] colors = {Color.red, Color.green, Color.blue, Color.yellow, Color.cyan};
		int n = Random.Range(1, 6);			// Bonus 아이템 번호 
		
		Vector3 pos = transform.position;	// 운석의 좌표 
		Transform obj = Instantiate(bonus, pos, Quaternion.identity) as Transform;
		
		obj.tag = "BONUS" + n;
		obj.renderer.material.color = colors[n - 1];
	}
	
	//--------------------------
	// 운석 초기화 
	//--------------------------
	void SetAsteroid () {
		// 속도와 보호막 
		speed = Random.Range(2.5f, 4);
		shield = Random.Range(0, 6);
		
		// 운석의 크기 
		Vector3 size;
		size.x = Random.Range(0.5f, 1.2f);
		size.y = Random.Range(0.5f, 1.2f);
		size.z = Random.Range(0.5f, 1.2f);
		transform.localScale = size;
		
		// 운석의 회전 각도 
		rot.x = Random.Range(-90, 90);
		rot.y = Random.Range(-90, 90);
		rot.z = Random.Range(-90, 90);
		
		// 운석의 색깔
		float red = Random.Range(0.6f, 1);
		transform.renderer.material.color = new Vector4(red, 0.6f, 0.6f, 1);
	}
}
