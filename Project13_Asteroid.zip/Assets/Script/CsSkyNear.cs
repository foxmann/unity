﻿using UnityEngine;
using System.Collections;

public class CsSkyNear : MonoBehaviour {
	
	public Transform asteroid;				// 운석 
	public Transform mine;					// 기뢰 
	
	Transform start;				// 출발지 
	Transform dest;					// 목적지 
	Transform planet;				// 행성 
	
	Vector3 dir = Vector3.zero;		// 이동 거리 
	
	float speed = 5;				// 이동 속도 
	
	//--------------------------
	// 게임 초기화 
	//--------------------------
	void Start () {
		start = GameObject.Find("출발지").transform;
		dest = GameObject.Find("목적지").transform;
		planet = GameObject.Find("행성").transform;
	}
	
	//--------------------------
	// Game Loop
	//--------------------------
	void Update () {
		MoveSky();			// 근경 이동 
		MoveObject();		// 출발지, 목적지 등 이동 
		
		Vector3 pos1 = start.position;		// 출발지 좌표 
		Vector3 pos2 = dest.position;		// 목적지 좌표 
		
		// 출발지와 목적지 근처에는 운석을 만들지 않음 
		if ((Mathf.Abs(pos1.x) > 10 || Mathf.Abs(pos1.y) > 10) &&
			(Mathf.Abs(pos2.x) > 20 || Mathf.Abs(pos2.y) > 20)) {
			MakeAsteroid();
		}	
	}	
		
	//--------------------------
	// 근경 이동 
	//--------------------------
	void MoveSky () {
		float amtMove = speed * Time.smoothDeltaTime;
		
		// 우주선의 방향에 따른 이동 거리 계산 
		dir.x = amtMove * CsShip.dir.x;
		dir.z = amtMove * CsShip.dir.y;
		
		// 이동 
		Vector3 pos = transform.position;
		pos -= dir;
		
		// 좌우로 화면을 벗어나면 반대 위치로 이동
		if (Mathf.Abs(pos.x) > 30) {
			pos.x = -pos.x;
		}
		
		// 상하로 화면을 벗어나면 반대 위치로 이동
		if (Mathf.Abs(pos.z) > 20) {
			pos.z = -pos.z;
		}
		
		transform.position = pos;
	}
	
	//--------------------------
	// Object 이동 
	//--------------------------
	void MoveObject () {
		// 행성 이동 
		planet.position -= dir * 0.3f;
		
		if (CsManager.state == CsManager.STATE.WAIT || CsManager.state == CsManager.STATE.COMBAT) { 
			return;
		}	
		
		// 출발지와 목적지 이동 
		start.position -= dir;		
		dest.position -= dir;		
	}
	
	//--------------------------
	// 운석 만들기 
	//--------------------------
	void MakeAsteroid () {
		if (Random.Range(0, 1000) < 970) return;
		
		// 우주선의 회전각을 12구간으로 구분(0~11) 
		int n = (int) Mathf.Floor((CsShip.dir.z + 15) / 30);
		if (n >= 12) n = 0; 
		
		// 우주선 구간에 가장 가까운 3의 배수영역(0,3,6,9) 찾기 
		int n3 = n / 3 * 3;
		
		// 운석 만들기 
		SetAsteroid(n3);

		// 우주선이 대각선 방향인 경우 다음 영역에 운석 만들기 
		if (n % 3 > 0) {
			n3 += 3;
			if (n3 >= 12) n3 = 0;
			SetAsteroid(n3);
		}
	}
	
	//--------------------------
	// 운석 좌표 계산 
	//--------------------------
	void SetAsteroid(int n) {
		// 운석 좌표 초기화 
		Vector3 pos	= Vector3.zero;
		
		switch (n) {
		case 0 :	// 12시 방향 
		case 6 :	// 6시 방향 
			pos.x = Random.Range(-10, 10f);
			pos.z = 6.5f;
			if (n == 6) pos.z = -6.5f;
			break;			
		case 3 :	// 3시 방향 
		case 9 :	// 9시 방향 
			pos.x = 10;
			pos.z = Random.Range(-6.5f, 6.5f);
			if (n == 9) pos.x = -10;
			break;			
		}
		
		// 운석과 기뢰의 비율 설정
		if (Random.Range(0, 100) > 20) {
			Instantiate(asteroid, pos, Quaternion.identity);	
		} else {
			Instantiate(mine, pos, Quaternion.identity);	
		}
	}
}
