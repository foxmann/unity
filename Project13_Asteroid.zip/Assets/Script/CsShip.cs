using UnityEngine;
using System.Collections;

public class CsShip : MonoBehaviour {
	
	public Transform laser;				// 프리팹 - 레이저 
	public Transform expSmall;			// 폭파 불꽃 작은 것 

	public AudioClip sndLaser;			// 사운드 - 레이저 발사 
	public AudioClip sndAlert;			// 경고 - 적기 출현 
	public AudioClip sndAttacked;		// 우주선 피격됨 
	public AudioClip sndDestroy;		// 우주선 파괴됨 
	
	Transform spPointL;					// Swan Point
	Transform spPointR;
	Transform ship;						// 우주선 본체(3D Object)
	
	static public int shield = 10;		// 보호막 
	int undeadTime = 0;					// 무적 상태 시간  
	
	static public Vector3 dir;			// 우주선 회전 방향 (x, y 절편, 회전 각도) 
	
	int rotSpeed = 120;					// 회전 속도 
	int speed = 10;						// 이동 속도 
	
	Quaternion org;						// 우주선의 마지막 방향 
	Color color1, color2;				// 우주선의 색깔 
	
	bool isCombat = false;				// 전투 모드인가?
	bool isMove = false;				// 자동 운행모드?
	bool isUndead = false;				// 무적상태?
	
	// Mobile 전용
	GUITexture btnLeft;
	GUITexture btnRight;
	GUITexture btnFire1;
	GUITexture btnFire2;
	
	bool isMobile = false;
	
	//----------------------
	// 게임 초기화 
	//----------------------
	void Start () {
		InitGame();
	}
	
	//----------------------
	// 게임 루프
	//----------------------
	void Update () {
		if (CsManager.state == CsManager.STATE.WAIT) return;
		
		if (!isCombat) {		// 전투 모드가 아니면 
			RotateShip();		// 우주선 회전 
		} else {				// 전투 모드이면 
			MoveShip();			// 우주선 이동
		}
		
		// 레이저 발사 
		if (!isMobile) {	// PC
			if (Input.GetKeyDown(KeyCode.LeftControl)) FireLaser();	
		} else {			// Mobile
			foreach (Touch tmp in Input.touches) {
				if (tmp.phase == TouchPhase.Began && 
				   (btnFire1.HitTest(tmp.position) || btnFire2.HitTest(tmp.position))) {
					FireLaser();	
				}	
			}
		}
		
		// 마우스로 회전 및 발사 
		if (!isCombat && Input.GetMouseButtonDown(0)) {
			StartCoroutine("RotateAndFire");
		}
		
		CalcRotation();			// 우주선의 회전 방향 계산 
	}
	
	//----------------------
	// 우주선 회전
	//----------------------
	void RotateShip () {
		if (isMove) return;			// 자동 운행 모드이면 키입력 무시
		
		var dir = Vector3.zero;		// 우주선의 회전 방향 
		
		if (!isMobile) {	// PC
			dir.y = Input.GetAxis("Horizontal") * rotSpeed;
		} else {			// Mobile
			foreach (Touch tmp in Input.touches) {
				if (btnLeft.HitTest(tmp.position)) dir.y = -rotSpeed;	
				if (btnRight.HitTest(tmp.position)) dir.y = rotSpeed;	
			}	
		}
		
		transform.Rotate(dir * Time.smoothDeltaTime);
	}
	
	//----------------------
	// 우주선 이동
	//----------------------
	void MoveShip () {
		if (isMove) return;				// 자동 운행 모드이면 키입력 무시
		
		Vector3 dir = Vector3.zero;		// 우주선의 이동 방향 
		
		// 우주선의 위치를 2D 좌표로 전환 
		Vector3 view = Camera.main.WorldToScreenPoint(transform.position);
		int width = Screen.width;	// 화면의 폭 
		
		if (!isMobile) {
			float key = Input.GetAxis("Horizontal");
			if ((key < 0 && view.x > width * 0.05f) || (key > 0 && view.x < width * 0.72f)) {
				dir.x = key * speed;
			}
		} else {
			foreach (Touch tmp in Input.touches) {
				if (btnLeft.HitTest(tmp.position) && view.x > width * 0.05f) {
					dir.x = -speed * 0.5f;
				}
				if (btnRight.HitTest(tmp.position) && view.x < width * 0.72f) {
					dir.x = speed * 0.5f;
				}
			}	
		}
		
		transform.Translate(dir * Time.smoothDeltaTime);
	}
	
	//---------------------------
	// 레이저 발사 
	//---------------------------
	void FireLaser () {
		AudioSource.PlayClipAtPoint(sndLaser, transform.position);
		
		Instantiate(laser, spPointL.position, spPointL.rotation);
		Instantiate(laser, spPointR.position, spPointR.rotation);
	}
	
	//---------------------------
	// 우주선 회전 및 레이저 발사 
	//---------------------------
	IEnumerator RotateAndFire() {
		Vector3 pos = Input.mousePosition;	// 마우스 위치 
		pos.z = 12;							// 카메라와 평면과 수직 거리 
		
		// Mobile 버튼 처리중인가?
		if (btnLeft.HitTest(pos) || btnRight.HitTest(pos) || 
			btnFire1.HitTest(pos) || btnFire2.HitTest(pos)) {
			yield break;	
		}
		
		// 마우스 위치를 월드 좌표로 변환 
		Vector3 target = Camera.main.ScreenToWorldPoint(pos);
		transform.LookAt(target);			// 우주선을 마우스 위치로 회전 
		
		// 목표 탐지 
		RaycastHit hit;
		Ray ray = Camera.main.ScreenPointToRay(pos);
		if (Physics.Raycast(ray, out hit, Mathf.Infinity)) {
			if (hit.transform.tag != "Untagged") {
				for (int i = 1; i <= 3; i++) {
					FireLaser();					// 레이저 3회 발사 
					yield return new WaitForSeconds(0.1f);
				}
			}
		} // if
	}
	
	//----------------------
	// 우주선의 무적 상태
	//----------------------
	IEnumerator UndeadShip (int time) {
		undeadTime = time;
		isUndead = true;
		
		// 무적 상태 유지 
		while (undeadTime > 0) {
			// 우주선을 빨간색으로 설정 
			ship.renderer.materials[2].color = new Vector4(1, 0, 0, 1);
			ship.renderer.materials[3].color = new Vector4(1, 0, 0, 1);
			yield return new WaitForSeconds(0.5f);
			
			// 원래의 색으로 복원
			ship.renderer.materials[2].color = color1;
			ship.renderer.materials[3].color = color2;
			yield return new WaitForSeconds(0.5f);
			
			undeadTime--;
		}
		
		isUndead = false;
	}
		
	//---------------------------
	// 전투 모드로 전환 - 외부 호출 
	//---------------------------
	IEnumerator EnterCombat() {
		isMove = true;						// 자동 운행 모드 설정 
		
		// 적기 출현 경고 사운드 
		AudioSource.PlayClipAtPoint(sndAlert, transform.position);
		isCombat = true;					// 전투 모드 설정
		org = transform.rotation;			// 현재의 우주선 방향 보존 
		
		StartCoroutine("UndeadShip", 5);	// 	5초간 무적 상태 유지
		
		// 우주선의 회전방향 계산 (1: 오른쪽, -1: 왼쪽)
		Vector3 euler = transform.eulerAngles;
		int dir = (euler.y > 180) ? 1 : -1;
		
		// 우주선이 수직에 가까워지도록 회전 
		do {
			// 우주선 회전 
			float rotSpeed = 120 * Time.smoothDeltaTime;
			transform.Rotate(Vector3.up * rotSpeed * dir);
			
			// 화면 갱신때까지 대기 
			yield return new WaitForFixedUpdate();
			euler = transform.eulerAngles;		// 회전 후의 회전각 계산 
		} while (Mathf.Abs(euler.y) > 3f);		// ±3도 이상이면 회전 계속 
		
		// 우주선을 수직으로 고정 
		transform.rotation = Quaternion.identity;
		
		// 이동 
		Vector3 pos;
		do {
			// 우주선을 화면의 아래로 이동 
			float amtMove = speed * 0.3f * Time.smoothDeltaTime;
			transform.Translate(Vector3.back * amtMove);
			
			// 화면 갱신때까지 대기 
			yield return new WaitForFixedUpdate();
			
			// 우주선이 화면의 아래를 벗어나지 않도록 조치 
			pos = Camera.main.WorldToScreenPoint(transform.position);
		} while (pos.y > Screen.height * 0.1f);
		
		isMove = false;				// 자동 운행 모드 해제 
	}
	
	//---------------------------
	// 운행 모드로 전환 - 외부 호출 
	//---------------------------
	IEnumerator EnterMove() {
		isMove = true;						// 자동 운행 모드 설정 
		StartCoroutine("UndeadShip", 5);	// 5초간 무적 상태 유지 
		
		// 회전 방향 계산 : 중심에서 우주선까지의 거리 
		Vector3 target = Vector3.zero - transform.position;
		Quaternion rotation = Quaternion.LookRotation(target);
		
		float y = rotation.eulerAngles.y;	// 회전할 각도 
		float dir = (y > 180) ? -1 : 1;		// 회전 방향 설정(-1:왼쪽, 1:오른쪽)  
		
		// 화면의 중심 방향으로 회전 
		do {
			float rotSpeed = 60 * Time.smoothDeltaTime;
			transform.Rotate(Vector3.up * rotSpeed * dir);
			
			yield return new WaitForFixedUpdate();
		} while (Mathf.Abs(transform.eulerAngles.y - y) > 2f);
		
		transform.rotation = rotation;			// 우주선의 각도 보정 
		
		// 화면의 중심으로 이동 
		float dist;
		do {
			float amtMove = speed / 2 * Time.smoothDeltaTime;
			transform.Translate(Vector3.forward * amtMove);
			
			yield return new WaitForFixedUpdate();
			
			// 남은 거리 계산 
			dist = Vector3.Distance(Vector3.zero, transform.position);
		} while (dist > 0.3f);
		
		transform.position = Vector3.zero;		// 우주선의 위치 보정 
		
		// 목적지 방향 계산 
		y = transform.eulerAngles.y - org.eulerAngles.y;
		dir = (y > 0) ? -1 : 1;		// 회전 방향 설정(-1:왼쪽, 1:오른쪽)  
		
		do {
			float rotSpeed = 60 * Time.smoothDeltaTime;
			transform.Rotate(Vector3.up * rotSpeed * dir);
			
			yield return new WaitForFixedUpdate();
		} while (Mathf.Abs(transform.eulerAngles.y - org.eulerAngles.y) > 3f);
		
		transform.rotation = org;			// 우주선의 각도 보정 
		
		isCombat = false;		// 전투 모드 해제 
		isMove = false;			// 자동 운행 모드 해제
		
		CsManager.state = CsManager.STATE.IDLE;
	}
	
	//----------------------
	// 우주선의 충돌 판정
	//----------------------
	void OnTriggerEnter(Collider coll) {
		switch (coll.tag) {
		case "MISSILE" :			// 미사일 
		case "BULLET"  :			// 포탄 
			if (!isUndead) shield--;
			
			// 포탄 등과의 충돌 처리 함수 호출
			Attacked(coll.transform.position);
			Destroy(coll.gameObject);
			break;
		case "MINE"	:				// 기뢰 
			coll.SendMessage("DestroySelf", SendMessageOptions.DontRequireReceiver);
			
			// 무적 상태가 아니면 우주선 파괴
			if (!isUndead) {
				StartCoroutine("DestroySelf");
			}	
			break;
		case "ASTEROID" :			// 운석 	
			if (!isUndead) shield--;
			
			Attacked(coll.transform.position);
			coll.SendMessage("DestroySelf", SendMessageOptions.DontRequireReceiver);
			break;
		}
		
		// Bonus Item 처리 
		if (coll.tag.Contains("BONUS")) {
			coll.SendMessage("GetBonusItem", SendMessageOptions.DontRequireReceiver);
		}
	}
		
	//----------------------
	// 우주선 피격
	//----------------------
	void Attacked (Vector3 pos) {
		// 우주선 피격음 
		AudioSource.PlayClipAtPoint(sndAttacked, pos);
		
		if (shield > 0) {				// 작은 불꽃 표시 
			Instantiate(expSmall, pos, Quaternion.identity);	
		} else {						// 우주선 파괴 
			StartCoroutine("DestroySelf");	
		}
	}
	
	//---------------------------
	// 우주선 파괴 
	//---------------------------
	IEnumerator DestroySelf () {
		// 우주선 폭파음 
		AudioSource.PlayClipAtPoint(sndDestroy, transform.position);
		shield = 0;		// 보호막 
		
		// 시간차를 두고 여기저기에 작은 폭파 불꽃 표시 
		for (int i = 1; i <= 10; i++) {
			Vector3 pos = transform.position;
			pos.x = Random.Range(pos.x - 0.5f, pos.x + 0.5f);
			pos.z = Random.Range(pos.z - 0.5f, pos.z + 0.5f);
			
			Instantiate(expSmall, pos, Quaternion.identity);
			
			yield return new WaitForSeconds(0.05f);
		}
		
		// 우주선을 배경 아래로 이동 
		Vector3 shipPos = transform.position;
		shipPos.y = -10;
		transform.position = shipPos;
		
		// GameManager에 통지 
		CsManager.state = CsManager.STATE.LOST;
	}
	
	//----------------------
	// 우주선의 회전 방향 계산 
	//----------------------
	void CalcRotation () {
		// 회전 각도 
		dir.z = transform.eulerAngles.y;
		
		// 회전 방향에 따른 절편 
		dir.x = Mathf.Sin(dir.z * Mathf.Deg2Rad);	// 회전각을 라디안으로 처리 
		dir.y = Mathf.Cos(dir.z * Mathf.Deg2Rad);
	}
	
	//----------------------
	// 게임 초기화 
	//----------------------
	void InitGame () {
		// Spawn Point 찾기 
		spPointL = transform.Find("spPointL");
		spPointR = transform.Find("spPointR");
		
		// 우주선 본체 
		ship = transform.Find("spaceship");
		
		// 우주선의 색깔 읽기 - 무적상태 처리용 
		color1 = ship.renderer.materials[2].color;
		color2 = ship.renderer.materials[3].color;
		
		// Mobile 기기용 
		if (Application.platform == RuntimePlatform.Android ||
			Application.platform == RuntimePlatform.IPhonePlayer) {
			isMobile = true;	
		}
		
		// 버튼 읽기 
		btnLeft = GameObject.Find("btnLeft").guiTexture;
		btnRight = GameObject.Find("btnRight").guiTexture;
		btnFire1 = GameObject.Find("btnFire1").guiTexture;
		btnFire2 = GameObject.Find("btnFire2").guiTexture;
		
		// 버튼 활성화 
		btnLeft.enabled = isMobile;
		btnRight.enabled = isMobile;
		btnFire1.enabled = isMobile;
		btnFire2.enabled = isMobile;
	}
	
} // end of script
