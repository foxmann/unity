using UnityEngine;
using System.Collections;

public class CsBird : MonoBehaviour {

	public int cellCnt = 6;		 // 전체 이미지 수 
	public int cellsPerSec = 10; // 1초에 표시할 셀의 수 
	
	float frmDelay;				 // 각 프레임의 지연시간 
	int cellNum = 0;			 // 현재의 셀번호 
	
	float cellOfs;				 // 매트리얼의 셀 오프셋 
	bool canNext = true;		 // 다음 장면? 
	bool canAni = true;			 // 애니메이션이 필요한가?
	
	float speed = 1.5f;			 // 이동 속도 
	
	// 애니메이션 초기화 
	void Start () 
	{
		cellOfs = 1.0f / cellCnt;		// 매트리얼의 이미지 오프셋 
		frmDelay = 1.0f / cellsPerSec;	// 프레임 지연 시간 
	}
	
	// 게임 루프 
	void Update () 
	{
		if (canAni) StartCoroutine("Animation");
		MoveBird();
	}
	
	// 애니메이션 
	IEnumerator Animation() 
	{
		if (canNext) {
			canNext = false;
			
			cellNum = (int) Mathf.Repeat(++cellNum, cellCnt);
			float ofs = cellOfs * cellNum;	
			transform.renderer.material.mainTextureOffset = new Vector2(ofs, 0);
			
			yield return new WaitForSeconds(frmDelay);
			canNext = true;
		}
	}
	
	// 이동 
	void MoveBird() 
	{
		float amtMove = speed * Time.smoothDeltaTime;
		transform.Translate(Vector3.right * amtMove);

		if (transform.position.x > 5) {
			Vector3 pos = transform.position;
			pos.x = -5;
			transform.position = pos;
		}
	}
	
}

