using UnityEngine;
using System.Collections;

public class CsFireBall : MonoBehaviour {
	
	public Transform fire;		// 화염 
	public AudioClip sndFire;	// 화염 사운드 
	
	GameObject human;			// 주인공 
	
	Vector3 target;				// 목적지 
	int speed = 5;
	
	//--------------------------------
	// Start
	//--------------------------------
	void Start () {
		human = GameObject.Find("Human");
	}
	
	//--------------------------------
	// Game Loop
	//--------------------------------
	void Update () {
		transform.LookAt(target);	// 목적지 방향으로 회전 - 테스트용  
		
		float amtMove = speed * Time.smoothDeltaTime;
		transform.Translate(Vector3.forward * amtMove);
		
		// 목적지까지 남은 거리 계산
		float dist = Vector3.Distance(transform.position, target);
		
		// 목적지 근처에서 폭발 
		if (dist <= 0.1f) {
			ExplodeFireBall();		// 화염 만들기 
		}
	}
	
	//--------------------------------
	// 충돌 처리 
	//--------------------------------
	void OnCollisionEnter (Collision coll) {
			ExplodeFireBall();
	}
	
	//--------------------------------
	// 화염탄 폭발 
	//--------------------------------
	void ExplodeFireBall () {
		try {
			// 화염 만들기 
			Transform obj = Instantiate(fire, transform.position, Quaternion.identity) as Transform;
			
			// 주인공과 충돌 금지 
			Physics.IgnoreCollision(obj.collider, human.collider);
			
			AudioSource.PlayClipAtPoint(sndFire, transform.position);
			Destroy(gameObject);	// 화염탄 제거 
		} catch {
			// nothing	
		}
	}
	
	//--------------------------------
	// 목적지 설정 - 외부 호출 
	//--------------------------------
	void SetTarget (Vector3 target) {
		this.target = target;
	}
}