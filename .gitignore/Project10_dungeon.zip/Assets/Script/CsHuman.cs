﻿using UnityEngine;
using System.Collections;

public class CsHuman : MonoBehaviour {

	public GUISkin skin;			// GUI Skin
	
	public AudioClip sndStage;		// 배경 음악 및 효과음 
	public AudioClip sndOver;
	public AudioClip sndLaser;		// 레이저 발사음 
	public AudioClip sndFireball;	// 화염탄 발사음 
	public AudioClip sndMedpack;	
	public AudioClip sndWarp;
		
	public Transform alien;			// 프리팹 
	public Transform medpack;		
	public Transform laser;
	public Transform fireBall;
	
	Transform mainCamera;			// Main Camara
	Transform spPoint;				// Spawn Point
	Transform floor;				// 스테이지의 바닥 
	
	Vector3 lookDir;				// 회전 방향 
	
	public static int score = 0;
	public static int hit = 0;
	
	float HP = 100;					// HP
	int speed = 10;
	int floorNum = 1;				// 현재 바닥의 이미지 번호 

	
	bool isDead = false;			// 사망?
	bool canLaser = true;			// 레이저 발사 가능?
	bool canFire = true;			// 화염탄 발사 가능?
	
	//--------------------------------
	// Game 초기화 
	//--------------------------------
	void Start () {
		mainCamera = GameObject.Find("Main Camera").transform;
		spPoint = transform.Find("spPoint");
		floor = GameObject.Find("바닥").transform;
		
		HP = 100;
		score = hit = 0;
		
		Screen.showCursor = false;
	}	
	
	//--------------------------------
	// Game Loop
	//--------------------------------
	void Update () {
		if (isDead) return;
		
		isDead = (HP < 0);	// HP를 모두 잃으면 주인공 사망 
		
		MoveHuman();		// 주인공 이동 
		RotateHuman();		// 주인공 회전 

		// 레이저 발사 
		if (canLaser && Input.GetMouseButton(0)) {
			StartCoroutine("ShotLaser");	
		}
	
		// 화염탄 발사
		if (canFire && (Input.GetMouseButton(1) || Input.GetMouseButton(2))) {
			StartCoroutine("ShotFireBall");	
		}
		
		// Alien 만들기 
		MakeAlien();
		
		HP = Mathf.Clamp(HP + 2 * Time.deltaTime, 0, 100);
		transform.renderer.material.color = new Vector4(1, 1, 1, HP / 100);
	}
	
	//--------------------------------
	// Move Human
	//--------------------------------
	void MoveHuman () {
		float amtMove = speed * Time.smoothDeltaTime;
		
		float keyForward = Input.GetAxis("Vertical");
		float keySide = Input.GetAxis("Horizontal");
		
		transform.Translate(new Vector3(keySide, 0, keyForward) * amtMove, Space.World);
		
		// 주인공의 위치 
		Vector3 pos = transform.position;
		pos.y = 10;			// 카메라의 높이 
		pos.z -= 10;		// 카메라의 후방 위치 
		
		mainCamera.position = pos;	// 카메라 이동 
	}	
	
	//--------------------------------
	// Rotate Human
	//--------------------------------
 	void RotateHuman () {
		RaycastHit hit;
		
		// 마우스 위치를 Ray로 변환 
		Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
		
		// 마우스 위치의 목표물 찾기 
		if (Physics.Raycast(ray, out hit, Mathf.Infinity)) {
			lookDir = hit.point;
			lookDir.y = 0;
		}
		
		transform.LookAt(lookDir);	// 목표물 방향으로 회전 
	}
	
	//--------------------------------
	// 레이저 발사
	//--------------------------------
 	IEnumerator ShotLaser () {
		canLaser = false;		// 연속 사격 금지 
		
		// 레이저 만들기 
		Transform obj = Instantiate (laser, spPoint.position, spPoint.rotation) as Transform;
		
		// 레이저의 충돌 판정 금지  
		Physics.IgnoreCollision(obj.collider, transform.collider);
		Physics.IgnoreCollision(obj.collider, floor.collider);
		
		AudioSource.PlayClipAtPoint(sndLaser, transform.position);
		
		yield return new WaitForSeconds(0.2f);
		canLaser = true;
	}

	//--------------------------------
	// 화염탄 발사
	//--------------------------------
 	IEnumerator ShotFireBall () {
		canFire = false;		// 연속 사격 금지 
		
		// 화염탄 만들기 
		Transform obj = Instantiate (fireBall, spPoint.position, spPoint.rotation) as Transform;
		
		// 화염탄과 Human과의 충돌 판정 금지  
		Physics.IgnoreCollision(obj.collider, transform.collider);
		
		// 화염탄의 목적지 설정 
		obj.SendMessage("SetTarget", lookDir, SendMessageOptions.DontRequireReceiver);
		
		yield return new WaitForSeconds(2f);
		canFire = true;
	}
	
	//--------------------------------
	// 충돌 처리 - 충돌 시작 
	//--------------------------------
 	void OnCollisionEnter (Collision coll) {
		if (isDead) return;
		
		switch (coll.transform.tag) {
		case "WARP" :
			SetNewFloor();
			break;
		case "MEDPACK" :
			HP = Mathf.Clamp(HP + 20, 0, 100);
			
			AudioSource.PlayClipAtPoint(sndMedpack, transform.position);
			Destroy(coll.gameObject);
			break;
		case "ALIEN" :
			HP -= 5;
			break;
		}
		print (HP);
	}
	
	//--------------------------------
	// 충돌 처리 - 충돌 진행중 
	//--------------------------------
 	void OnCollisionStay (Collision coll) {
		if (!isDead && coll.transform.tag == "ALIEN") {
			HP -= 0.1f;
		}
		Debug.Log(HP);
	}
	
	//--------------------------------
	// 새 스테이지 설정 
	//--------------------------------
 	void SetNewFloor () {
		int n;
		
		do {
			n = Random.Range(1, 5);
		} while (n == floorNum);
		
		floorNum = n;
		floor.renderer.material.mainTexture = Resources.Load("floor" + n) as Texture2D;
		
		transform.position = Vector3.zero;
	}

	
	//--------------------------------
	// Alien 만들기 
	//--------------------------------
 	void MakeAlien () {
		if (Random.Range(0, 1000) < 990) return;
		
		int w = Screen.width;		// 화면의 폭과 높이 
		int h = Screen.height;
		
		Vector3 pos = Vector3.zero;
		bool check = false;
		
		do {
			// Alien이 나타날 위치 
			pos.x = Random.Range(-17, 17f);
			pos.z = Random.Range(-17, 17f);
			
			// Alien의 좌표가 화면 밖인지 조사 
			Vector3 tmp = Camera.main.WorldToScreenPoint(pos);
			check = (tmp.x < 0 || tmp.x > w) && (tmp.y < 0 || tmp.y > h);
		} while (!check);
		
		if (Random.Range(0, 100) < 90) {
			Instantiate(alien, pos, Quaternion.identity);
		} else {
			Instantiate(medpack, pos, Quaternion.identity);
		}
	}
	
	//--------------------------------
	// GUI 
	//--------------------------------
	void OnGUI () {
		
		GUI.skin = skin;
		
		int w = Screen.width / 2;	
		int h = Screen.height / 2;
		
		string str1 = "<size=22><color=#80ff80>Score : ##</color></size>";
		string str2 = "<size=22><color=#80ff80>Hit : ##</color></size>";
		string str3 = "<size=22><color=#80ff80>HP</color></size>";
		
		// Progressbar 그리기 
		DrawProgress();
		
		// Score Board 그리기 
		GUI.DrawTexture(new Rect(0, 0, w * 2, 52), Resources.Load ("score_board") as Texture2D);
		
		// 점수 표시 
		GUI.Label(new Rect(w * 0.2f, 16, 250, 50), str1.Replace("##", "" + score));
		GUI.Label(new Rect(w * 0.82f, 16, 250, 50), str2.Replace("##", "" + hit));
		GUI.Label(new Rect(w * 1.56f, 5, 80, 50), str3);
		
		// 조준선 그리기 
		if (!isDead) {
			Vector2 t = Input.mousePosition;
			t.y = Screen.height - t.y;
		
			GUI.DrawTexture(new Rect(t.x - 24, t.y - 24, 46, 48), Resources.Load ("crosshair") as Texture2D);
			
			return;
		}	
		
		// GameOver 처리 
		if (audio.clip != sndOver) {
			audio.clip = sndOver;
			audio.loop = false;
			audio.Play ();
			
			Screen.showCursor = true;
		}
		
		if (GUI.Button (new Rect(w - 60, h - 50, 120, 50), "Play Game")) {
			Application.LoadLevel("MainGame");	
		}
		
		if (GUI.Button (new Rect(w - 60, h + 50, 120, 50), "Quit Game")) {
			Application.Quit();
		}
	}
	
	//--------------------------------
	// Progressbar 그리기 
	//--------------------------------
	void DrawProgress () {
		int w = Screen.width;
		float x = w * 0.81f;		// 프로그래스바 시작 위치 
		
		float bw = x * 0.22f;		// 프로그레스바의 폭 
		float pw = bw * HP / 100;	// HP의 폭 
		
		GUI.DrawTexture(new Rect(x, 5, bw, 20), Resources.Load ("progress_back") as Texture2D);
		GUI.DrawTexture(new Rect(x, 5, pw, 20), Resources.Load ("progress_bar") as Texture2D);
	}
	
} // end of clss		


