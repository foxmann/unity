using UnityEngine;
using System.Collections;

public class CsAutoDoor : MonoBehaviour {
	
	Transform human;		// 주인공 
	Light doorLight;		// 조명 			
	Transform door;			// 자동문 
	
	//--------------------------------
	// 시작시 Object 찾기
	//--------------------------------
	void Start () {
		human = GameObject.Find("Human").transform;
		doorLight = transform.Find("Point light").light;
		door = transform.Find("Door");
	}
	
	//--------------------------------
	// Game Loop
	//--------------------------------
	void Update () {
		
		// 주인공과의 거리 계산 
		float dist = Vector3.Distance(transform.position, human.position);
		
		// 전등 켜고 끄기 			
		doorLight.enabled = (dist <= 5);
		
		// 문 열기 
		if (dist <= 2) {
			door.animation.Play();
		}
	}
}