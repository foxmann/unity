using UnityEngine;
using System.Collections;

public class CsLaser : MonoBehaviour {

	int speed = 15;
	
	//--------------------------------
	// 이동 
	//--------------------------------
	void Update () {
		float amtMove = speed * Time.smoothDeltaTime;
		transform.Translate(Vector3.forward * amtMove);
	}
	
	//--------------------------------
	// 충돌 처리 
	//--------------------------------
	void OnTriggerEnter (Collider coll) {
		// Alien과 충돌인가?
		if (coll.tag == "ALIEN") {
			coll.SendMessage("DecreseHP", SendMessageOptions.DontRequireReceiver);
		}
		
		Destroy(gameObject);
	}
}
