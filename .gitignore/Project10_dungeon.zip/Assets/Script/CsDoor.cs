using UnityEngine;
using System.Collections;

public class CsDoor : MonoBehaviour {
	
	public AudioClip doorOpen;		// 문여는 소리
	public AudioClip doorClose;		// 문닫는 소리

	//--------------------------------
	// Animation Event
	//--------------------------------
	void OpenSound () {
		AudioSource.PlayClipAtPoint(doorOpen, transform.position);
	}
	
	//--------------------------------
	// Animation Event
	//--------------------------------
	void CloseSound () {
		AudioSource.PlayClipAtPoint(doorClose, transform.position);
	}
} 