using UnityEngine;
using System.Collections;

public class CsAlien : MonoBehaviour {

	public Transform alienExp;		// 프리팹 
	public AudioClip sndDead;		// Alien 사망 효과음 
	Transform human;				// 주인공 
			
	int speed;
	float HP;
	float delayTime = 1f;
		
	//--------------------------------
	// Game 초기화 
	//--------------------------------
	void Start () {
		human = GameObject.Find("Human").transform;
		
		speed = Random.Range(3, 6);
		HP = Random.Range(0, 6);
	}
	
	//--------------------------------
	// 이동 
	//--------------------------------
	void Update () {
		
		transform.LookAt(human);	// 주인공 방향으로 회전
		
		// 주인공과 거리 계산
		float dist = Vector3.Distance(transform.position, human.position);
		
		if (dist > 1) {
			float amtMove = speed * Time.smoothDeltaTime;
			transform.Translate(Vector3.forward * amtMove);
		}
	}
	
	//--------------------------------
	// 충돌 시작 
	//--------------------------------
	void OnCollisionEnter(Collision coll) {
		switch (coll.transform.tag) {
		case "WALL" : 		// 벽과 충돌하면 지연시간 설정 
			delayTime = 1;		
			break;
		case "FIRE" :		// 화염탄의 불꽃과 충돌하면 
			DecreseHP();	// HP 감소 
			break;			
		}
	}
	
	//--------------------------------
	// 충돌 진행중 
	//--------------------------------
	void OnCollisionStay(Collision coll) {
		switch (coll.transform.tag) {
		case "WALL" :
			delayTime -= Time.deltaTime;
			if (delayTime <= 0) {
				// 벽과의 충돌 무시 
				Physics.IgnoreCollision(transform.collider, coll.collider);
			}
			break;
		case "FIRE" : 
			DecreseHP();	// HP 감소 
			break;
		}
	}
	
	//--------------------------------
	// Laser와 충돌 - 외부 호출 
	//--------------------------------
	void DecreseHP () {
		// 득점 처리 
		CsHuman.score += 100;
		
		HP--;
		if (HP < 0) {
			CsHuman.score += 500;	
			CsHuman.hit++;			// 제거한 Alien 수 
			
			// Alien 폭파 
			Instantiate(alienExp, transform.position, Quaternion.identity);
			AudioSource.PlayClipAtPoint(sndDead, transform.position);
			Destroy(gameObject);
		}	
	}
}