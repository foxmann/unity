using UnityEngine;
using System.Collections;

public class CsBunker : MonoBehaviour {
	
	public Transform tank;		// 아군 탱크 
	public Transform bullet;	// 포탄 
	
	Transform spPoint;			// Spawn Point
	int power = 1200;			// 포탄 발사 파워 
	
	float delayTime = 0;		// 발사 지연 시간 
	
	// 게임 초기화 
	void Start () 
	{
		spPoint = transform.Find("spPoint");
	}
	
	// 게임 루프 
	void Update () 
	{
		transform.LookAt(tank);
		SearchTank();					// 탱크 탐색 
		delayTime -= Time.deltaTime;	// 지연시간 감소 
	}
	
	// 탱크 탐색 
	void SearchTank () 
	{
		Debug.DrawRay(spPoint.position, spPoint.forward * 15, Color.green);
		
		RaycastHit hit;
		if (Physics.Raycast(spPoint.position, spPoint.forward, out hit, 15)) {
			if (hit.transform.tag == "TANK") {
				FireBullet();	
			}	
		}
	}
	
	// 포탄 발사
	void FireBullet() 
	{
		if (delayTime <= 0) {
			delayTime = 2;
		
			Transform obj = Instantiate(bullet, spPoint.position, spPoint.rotation) as Transform;
			obj.rigidbody.AddForce(spPoint.forward * power);
		}
	}
}
