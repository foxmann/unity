using UnityEngine;
using System.Collections;

public class CsBullet : MonoBehaviour {
	
	public AudioClip sndExp;		// 폭파 사운드 
	public Transform explode;		// 불꽃 프리팹 
	
	// 게임루프 
	void Update ()
	{
		if (transform.position.y < 0) {		// 포탄의 높이 조사 
			Destroy(gameObject);
		}
	}
	
	// 충돌 처리  
	void OnTriggerEnter (Collider coll)
	{
		Instantiate(explode, transform.position, Quaternion.identity);
		AudioSource.PlayClipAtPoint(sndExp, transform.position);
		if (coll.tag == "WALL") {
			Destroy(coll.gameObject);
		}	
		
		if (coll.tag == "BUNKER") {
			Destroy(coll.transform.root.gameObject);
		}	
		
		Destroy(gameObject);
	}
}
