﻿using UnityEngine;
using System.Collections;

public class CsTank : MonoBehaviour {
	
	public GameObject turret;	// 포탑 
	public GameObject gun;		// 포신
	
	public Transform bullet;	// 포탄 프리팹 
	Transform spPoint;			// 스판 포인트 	
	int power = 1800;			// 포탄의 발사 파워  
	
	int moveSpeed = 10;			// 이동 속도- 초속 10m 
	int rotSpeed = 120;			// 회전 속도- 초속 120도 
		
	// 게임 초기화 
	void Start ()
	{
		spPoint = transform.Find("Turret/Cannon/spPoint");
		turret = transform.Find("Turret").gameObject;
		gun = transform.Find("Turret/Cannon").gameObject;
	}
		
	// 게임 루프 
	void Update ()
	{
		float amtMove = moveSpeed * Time.smoothDeltaTime;
		float amtRot = rotSpeed * Time.smoothDeltaTime;
		
		float keyMove = Input.GetAxis("Vertical");
		float keyRot = Input.GetAxis("Horizontal");
		
		float keyTurret = Input.GetAxis("Turret");	
		float keyGun = Input.GetAxis("Mouse ScrollWheel");	
		
		transform.Translate(Vector3.forward * amtMove * keyMove);
		transform.Rotate(Vector3.up * amtRot * keyRot);
		
		turret.transform.Rotate(Vector3.up * amtRot * keyTurret);
		gun.transform.Rotate(Vector3.right * keyGun * 4);
		
		Vector3 ang = gun.transform.eulerAngles;
		if (ang.x > 180)
			ang.x -= 360;
		ang.x = Mathf.Clamp(ang.x, -15, 5);
		
		gun.transform.eulerAngles = ang;
		
		if (Input.GetButtonDown("Fire1")) {
			FireBullet();	
		}
	} // update
	
	// 포탄 발사 
	void FireBullet ()
	{
		Transform obj = Instantiate(bullet, spPoint.position, spPoint.rotation) as Transform;
		obj.rigidbody.AddForce(spPoint.forward * power);
	}
} // end of class
