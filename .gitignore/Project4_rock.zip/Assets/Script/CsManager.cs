﻿using UnityEngine;
using System.Collections;

public class CsManager : MonoBehaviour {

	public GUISkin skin;			// GUI Skin 변수
    public GameObject objYou;		// 가위바위보 오브젝트 
    public GameObject objCom;

    public GUIText txtYou;			// GUI Text
    public GUIText txtCom;
    public GUIText txtScore;

    int you = 0;					// 가위바위보(가위:1, 바위:2, 보:3)
    int com = 0;
    int scYou = 0;					// 승패 점수 
    int scCom = 0;

    //--------------------------------
    // 승패 처리
    //--------------------------------
    void CheckScore ()
    {
		com = Random.Range(1, 4);		// 1~3의 난수
		objCom.renderer.material.mainTexture = Resources.Load("img_" + com) as Texture2D;
		objYou.renderer.material.mainTexture = Resources.Load("img_" + you) as Texture2D;
		
		// 승패 판정
		int k = you - com;

		if (k == 0) {
			txtScore.text = "비겼습니다";
		} else if (k == 1 || k == -2) {
			txtScore.text = "당신이 이겼습니다";
			scYou++;
		} else {
			txtScore.text = "컴퓨터가 이겼습니다";
			scCom++;
		}
			
		txtYou.text = "당신 : " + scYou;
		txtCom.text = "컴퓨터 : " + scCom;
		
		you = 0;
    }

    //--------------------------------
	// 화면 처리 
	//--------------------------------
	void OnGUI ()
	{
		GUI.skin = skin;		// GUI Skin 사용
		
		int w = Screen.width / 2;
		int h = Screen.height / 2;

        if (GUI.Button(new Rect(w * 0.5f - 60, h * 1.6f, 120, 50), "가위")) {
            you = 1;
        }
        if (GUI.Button(new Rect(w - 60, h * 1.6f, 120, 50), "바위")) {
            you = 2;
        }
        if (GUI.Button(new Rect(w * 1.5f - 60, h * 1.6f, 120, 50), "보")) {
            you = 3;
        }

        if (you > 0) {			// 버튼을 누르면 승패 판정
            CheckScore();
        }
    }
	
}// end of class










