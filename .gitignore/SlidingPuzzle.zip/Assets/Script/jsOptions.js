#pragma strict

var skin : GUISkin;

private var isPicture = false;
private var soundOn : boolean;
private var gridNum : int = 0;
private var imgSize : String[] = ["3x3", "3x4", "4x4", "4x5", "5x5", "5x6", "6x6"];

private var scrollPosition : Vector2 = Vector2.zero;

//-----------------------------
// Start
//-----------------------------
function Start() {
	audio.mute = !jsManager.isSound;
}

//-----------------------------
// OnGUI()
//-----------------------------
function OnGUI() {
	GUI.skin = skin;
	soundOn = jsManager.isSound;
	
	if (isPicture) {
		SelectPicture();
		return;
	}
	
	var w = Screen.width / 2;
	var h = Screen.height / 2;

	var msg = "Sound On";
	if (!soundOn) msg = "Sound Off";
	
	// Sound OnOff

	soundOn = GUI.Toggle(Rect(w - 80, h - 90, 160, 35), soundOn, " " + msg);
	audio.mute = !soundOn;
	jsManager.isSound = soundOn;
	
	// Image Size
	GUI.Label(Rect(w - 80, h - 60, 160, 35), "Image Size :");
	gridNum = GUI.SelectionGrid(Rect(w - 60, h - 30, 170, 90), gridNum, imgSize, 3);
	jsManager.stageNum = gridNum + 1;
	
	// 사진 선택
	isPicture = GUI.Button(Rect(w - 70, h + 75, 140, 35), "Select Picture"); 
	
	// Go back
	if (GUI.Button(Rect(w - 45, h + 120, 90, 35), "Go back")) {
		Application.LoadLevel("GameTitle");
	}	
}

//-----------------------------
// 사진 선택
//-----------------------------
function SelectPicture() {
	
	var mx : int = 90;		// 좌우 마진
	var my : int = 30;		// 상하 마진
	
	var winRect = Rect(mx, my, Screen.width - mx * 2, Screen.height - my * 1.5);

	var scrollRect = Rect(mx + 10, my + 25, Screen.width - mx * 2 - 20, Screen.height - my * 1.5 - 30);
	var scrollArea = Rect(0 ,0, Screen.width *0.6, Screen.height * 1.2);
	
	GUI.Window(1, winRect, WindowFunc, "Select Picture");
	
	scrollPosition = GUI.BeginScrollView (scrollRect, scrollPosition, scrollArea, false, false);
	var pw : int = Screen.width / 4.5;	// 사진의 가로 크기
	var ph : int = pw * 7 / 5;			// 사진의 세로 크기

	for (var i : int = 0; i < jsManager.picCount; i++) {
		var img : Texture2D = Resources.Load("picture" + (i + 1), Texture2D);	
		var x = i % 3;
		var y = i / 3;
		
		if (GUI.Button(Rect(pw * x, ph * y, pw - 20, ph - 15), img)) {
			jsManager.picNum = i + 1;
			isPicture = false;
		}	
	}		
	
	GUI.EndScrollView ();	
}

//-----------------------------
// GUI Window 처리 함수
//-----------------------------
function WindowFunc() {
	// nothing
}