#pragma strict

private var speed = 8;

// 타일 이동 방향
private var dirX : int[] = [ 0, 0, -1, 0, 1 ];
private var dirZ : int[] = [ 0, -1, 0, 1, 0 ];

//-----------------------------
// Mouse Up
//-----------------------------
function OnMouseUp() {
	if (jsManager.state == STATE.WAIT) return;
	
	jsManager.tileNum = int.Parse(transform.tag.Substring(4));
	jsManager.state = STATE.CLICK;
}

//-----------------------------
// Move
//-----------------------------
function MoveTile() {
	var posX = transform.position.x;	// 타일의 현재 위치
	var posZ = transform.position.z;
	
	var dir = jsManager.dir;		// 이동 방향
	var dist = 0.0;						// 이동할 거리
	
	if (dir == 1 || dir == 3)			// 수직 방향 이동
		dist = jsManager.sizeZ;
	if (dir == 2 || dir == 4)			// 수평 방향 이
		dist = jsManager.sizeX;
		
	while (dist > 0.1) {
		var amtToMoveX = speed * Time.deltaTime * dirX[dir];
		var amtToMoveZ = speed * Time.deltaTime * dirZ[dir];
		transform.Translate(Vector3(amtToMoveX, 0, amtToMoveZ));
		
		// 이동한 거리 누적
		if (dir == 1 || dir == 3)
			dist -= Mathf.Abs(amtToMoveZ);
		if (dir == 2 || dir == 4)
			dist -= Mathf.Abs(amtToMoveX);
		yield 0;
	}
	
	// 이동 후 핀트 맞춤
	switch (dir) {
		case 1 : transform.position.z = posZ + jsManager.sizeZ; break;	
		case 2 : transform.position.x = posX + jsManager.sizeX; break;	
		case 3 : transform.position.z = posZ - jsManager.sizeZ; break;	
		case 4 : transform.position.x = posX - jsManager.sizeX; break;	
	}
}
