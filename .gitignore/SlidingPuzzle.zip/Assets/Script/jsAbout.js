#pragma strict

var skin : GUISkin;

private var speed = 0.7;

//-----------------------------
// Update
//-----------------------------
function Update () {
	var amtToMove = speed * Time.deltaTime;
	transform.Translate(Vector3.back * amtToMove);
	
	if (transform.position.z > 4.8)
		transform.position.z = -10;
		
}

//-----------------------------
// OnGUI()
//-----------------------------
function OnGUI() {
	GUI.skin = skin;
	
	audio.mute = !jsManager.isSound;

	var w = Screen.width / 2;
	var h = Screen.height / 2;
	
	// Go back
	if (GUI.Button(Rect(w - 45, h + 120, 90, 35), "Go back")) {
		Application.LoadLevel("GameTitle");
	}	
}
