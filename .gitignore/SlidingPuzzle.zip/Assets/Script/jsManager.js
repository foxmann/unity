#pragma strict

import System.IO;						// 파일 Load & Save	

// GameObject - 인스펙터에서 할당
var skin 	 : GUISkin;					// GUI 스킨

var txtMove  : GUIText;					// 타일 이동 횟수
var txtStage : GUIText;					// 스테이지 번호
var txtTime  : GUIText;					// 경과 시간
var txtMsg   : GUIText;					// 메시지 표시

// 프리팹 & AudioClip - 인스펙터에서 할당
var fanfare    : Transform;				// 파티클 프리팹
var sndFanfare : AudioClip;				// 사운드
var sndClick   : AudioClip;

// 타일 수, 타일 크기
static  var dir : int = 0;				// 타일 이동 방향(1~4)
static var tileNum : int;				// 클릭한 타일 번호
private var countX : int;				// 타일의 수
private var countZ : int;

static var sizeX : float;				// 타일 사이즈
static var sizeZ : float;

// 스테이지 처리용
static  var isSound = true;				// 배경 음악 및 사운드 연주 여부
static  var stageNum  : int = 1;		// 스테이지 번호
private var stageTime : int = 0;		// 스테이지 경과 시간
private var moveCount : int = 0;		// 타일 이동 횟수

// 이미지 관련
static  var picNum 	  : int = 1;		// 사진 번호
static  var picCount  : int = 6;		// 사진 수

enum STATE { START, CLEAR, SAVE, LOAD, CLICK, IDLE, WAIT };
static var state : STATE = STATE.START;

// 타일의 수에 따른 타일의 크기
private var arTileSizeX : float[] = [ 0, 0, 0, 1f, 0.75f, 0.6f, 0.5f ];
private var arTileSizeZ : float[] = [ 0, 0, 0, 1.4f, 1.05f, 0.84f, 0.7f ];

// 스테이지에 따른 타일 수 (사진 6장의 경우)
private var arPicCountX : int[] = [ 0, 3, 3, 4, 4, 5, 5, 6 ];
private var arPicCountZ : int[] = [ 0, 3, 4, 4, 5, 5, 6, 6 ];

// 이동할 타일 : 타일 수, 공백 위치,  타일 번호...
private var arMoveQue : int[] = [ 0, 0, 0, 0, 0, 0 ];   

// 6x6 타일 번호
private var arTiles : int[] = new int[36];	

//-----------------------------
// Start
//-----------------------------
function Start() {
	audio.mute = !isSound;
}

//-----------------------------
// 순환 루프
//-----------------------------
function Update() {
	switch (state) {
		case STATE.START :
			MakeStage();
			break;
		case STATE.CLICK :
			CheckMove();
			if (dir > 0) {
				MoveTile();
				CheckClear();
			}	
			break;
		case STATE.CLEAR :
			StageClear();
			break;
		case STATE.SAVE :
			SaveStage();
			break;
		case STATE.LOAD :
			LoadStage();
			break;
	}	
}

//-----------------------------
// 스테이지 만들기
//-----------------------------
function MakeStage() {
	// 변수 초기화 	
	countX = arPicCountX[stageNum];	
	countZ = arPicCountZ[stageNum];

	sizeX = arTileSizeX[countX];		// 타일의 크기
	sizeZ = arTileSizeZ[countZ];
	
	if (state == STATE.START) {
		ShuffleTile();					// 타일 섞기
		stageTime = Time.time;			// 스테이지 시작 시각
	}	

	// 텍스처로 사용할 사진
	var img : Texture2D = Resources.Load("picture" + picNum, Texture2D);	

	for (var i : int = 0; i < countX * countZ; i++) {
		var col = i % countX;				// 열번호
		var row = i / countX;				// 행번호

		var x =  col * sizeX + sizeX / 2;	// 표시 위치
		var z =  row * sizeZ + sizeZ / 2;
	    
		var num = arTiles[i];				// 섞인 타일 번호
		if (num == -1) continue;			// 빈 타일
		
		// 동적으로 타일 만들기
		var tile : GameObject = Instantiate(Resources.Load("Prefabs/pfTile", GameObject));
		tile.transform.position = Vector3(x, 0, -z);
		
		// 타일 사이의 간격을 0.01로 설정
		tile.transform.localScale = Vector3(sizeX - 0.01, 0.05, sizeZ - 0.01);
		tile.tag = "TILE" + num;
	
		// 섞인 타일 번호로 col, row 계산
		var tCol : int = num % countX;		
		var tRow : int = num / countX;		
		
		// 텍스처 분할 
		var tilingX = 1.0 / countX;		// 텍스처 타일링 수
		var tilingY = 1.0 / countZ;

		var offsetX = tilingX * tCol;	// 텍스처 오프셋
		var offsetY = 1.0 - (tilingY * tRow) - tilingY;
		
		// 타일 랜더링
		tile.renderer.material.mainTextureScale = Vector2(tilingX, tilingY); 
		tile.renderer.material.mainTextureOffset = Vector2(offsetX, offsetY); 
		tile.renderer.material.mainTexture = img;
	}
	
	state = STATE.IDLE;
}

//-----------------------------
// 타일 섞기
//-----------------------------
function ShuffleTile() {
	var loop = countX * countZ - 1;
	
	// 초기값
	for (var i : int = 0; i <= loop; i++) {
		arTiles[i] = i;
	}
	arTiles[loop] = -1;		// 빈 타일은 -1
	
	return;
	
	// 섞기 	
	for (i = 0; i <= loop; i++) {
		var n1 = Random.Range(0, loop + 1);
		var n2 = Random.Range(0, loop + 1);
		
		// 서로 교환
		var tmp = arTiles[n1];
		arTiles[n1] = arTiles[n2];
		arTiles[n2] = tmp;
	}
	
	CheckShuffle();			// 무결성 조사
}

//-----------------------------
// 배열의 무결성 조사
//-----------------------------
function CheckShuffle() {
	var loop = countX * countZ;
	
	do {
		var cnt = 0;				// 치환의 수
		
		for (var i = 0; i < loop - 1; i++) {
			if (arTiles[i] == -1) continue;
			
			for (var j = i + 1; j < loop; j++) {
				if (arTiles[j] == -1) continue;
				
				if (arTiles[i] > arTiles[j]) {
					cnt++;
					var n1 = i;		// 임시 저장
					var n2 = j;
				}
			} // for j
		} // for i	
		
		if (cnt % 2 == 0) break;	// 완료
		var tmp = arTiles[n1];
		arTiles[n1] = arTiles[n2];
		arTiles[n2] = tmp;
	} while (cnt % 2 == 1);			 
}

//-----------------------------
// 타일이 이동가능한가?
//-----------------------------
function CheckMove() {
	var pos = CalcPoint(tileNum);	// 클릭한 타일 번호
	var target = CalcPoint(-1);		// 빈 타일 번호
	
	var posCol = pos % countX;		// 클릭한 타일의 col 
	var posRow = pos / countX;
	
	var tarCol = target % countX;	// 빈 타일의 col
	var tarRow = target / countX;
	
	if (posCol != tarCol && posRow != tarRow) return;	// 움직일 타일 없음
	
	// 수평 방향 계산
	if (posRow == tarRow)
		CalcHorizontal(pos, posCol, tarCol);
	else	
		CalcVertical(pos, posRow, tarRow);
		
	arMoveQue[1] = target; 			// 공백 위치
	
	// 디버그용
	print("Dir = " + dir + ", MoveCount = " + arMoveQue[0]);		
}

//-----------------------------
// 지정한 타일 위치 찾기
//-----------------------------
function CalcPoint(num) : int {
	var result = -9;
	
	// 배열을 순차적으로 검색
	for (var i = 0; i < countX * countZ; i++) {
		if (arTiles[i] == num) {
		 	result = i;
		 	break;
		 }
	}
	return result;	 	
}

//-----------------------------
// 수평 방향 이동할 타일 찾기
//-----------------------------
function CalcHorizontal(pos : int, posCol : int, tarCol : int) {
	var cnt = posCol - tarCol;			// 이동할 타일 수
	arMoveQue[0] = Mathf.Abs(cnt);		// 이동할 타일 수

	if (posCol < tarCol) {				// 오른쪽으로 이동
		dir = 2;
		for (var i = 0; i < -cnt; i++) {
			arMoveQue[i + 2] = pos + i;	// Click한 카드부터 저장
		}	
	} else {							// 왼쪽으로 이동	
		dir = 4;
		for (i = 0; i < cnt; i++) {
			arMoveQue[i + 2] = pos - i;
		}	
	}
}

//-----------------------------
// 수직 방향 이동할 타일 찾기
//-----------------------------
function CalcVertical(pos : int, posRow : int, tarRow : int) {
	var cnt = posRow - tarRow;			// 이동할 타일 수
	arMoveQue[0] = Mathf.Abs(cnt);		// 이동할 타일 수

	if (posRow < tarRow) {				// 아래로 이동
		dir = 3;
		for (var i = 0; i < -cnt; i++) {
			arMoveQue[i + 2] = pos + i * countX;		// Click한 카드부터 이동
		}	
	} else {							// 위로 이동
		dir = 1;
		for (i = 0; i < cnt; i++) {
			arMoveQue[i + 2] = pos - i * countX;
		}	
	}
}

//-----------------------------
// 타일 이동
//-----------------------------
function MoveTile() {
	state = STATE.WAIT;
	moveCount++;
	if (isSound)
		AudioSource.PlayClipAtPoint(sndClick, Vector3(1.5, 0, -2));

	var cnt = arMoveQue[0];				// 이동할 타일 수
	for (var i = 2; i <= cnt + 1; i++) {
		var num = arMoveQue[i];	
		var obj = GameObject.FindGameObjectWithTag("TILE" + arTiles[num]);
		obj.SendMessage("MoveTile", SendMessageOptions.DontRequireReceiver);
	}

	// 타일 이동 후 배열 정리
	var blk = arMoveQue[1];				// 공백 타일 위치
	var last = arMoveQue[cnt + 1];		// 마지막 타일 번호
	arTiles[blk] = arTiles[last];		// 공백 위치에 마지막 타일 번호 기록
	
	for (i = cnt + 1; i >= 3; i--) {
		num = arMoveQue[i];
		switch (dir) {
			case 1 : arTiles[num] = arTiles[num + countX]; break;	// 배열 이동
			case 2 : arTiles[num] = arTiles[num - 1]; break;	
			case 3 : arTiles[num] = arTiles[num - countX]; break;
			case 4 : arTiles[num] = arTiles[num + 1]; break;
		}	
	}

	num = arMoveQue[2];						// 클릭한 타일 번호
	arTiles[num] = -1;						// 클릭한 타일을 새로운 공백
	
	dir = 0;
	state = STATE.IDLE;
}

//-----------------------------
// 결과 판정
//-----------------------------
function CheckClear() {
	var isDone = true;
	var loop = countX * countZ;
	
	for (var i = 0; i < loop - 1; i++) {
		if (arTiles[i] != i) {
			isDone = false;
			break;
		}
	}
	
	if (isDone) 
		state = STATE.CLEAR;
}

//-----------------------------
// StageClear
//-----------------------------
function StageClear() {
	state = STATE.WAIT;
	Instantiate(fanfare, Vector3(1.5, 0.5, -2.5), Quaternion.identity);
	if (isSound)
		AudioSource.PlayClipAtPoint(sndFanfare, Vector3(1.5, 0, -2));
	
	// 메시지 표시
	for (var i = 1; i < 5; i++) {
		txtMsg.text = "Stage Clear!";
		yield WaitForSeconds(0.5);
		
		txtMsg.text = "";
		yield WaitForSeconds(0.5);
	}
	
	DeleteTiles();				// 현재의 타일 제거	
	stageNum++;					// 스테이지 증가	
	if (stageNum > picCount + 1)
		stageNum = 1;
		
	picNum++;
	if (picNum > picCount)
		picNum = 1;	
		
	// 변수 초기화	
	moveCount = 0;				// 타일 이동 횟수
	stageTime = 0;				// 스테이지 경과 시간
	
	state = STATE.START;
}

//-----------------------------
// Delete Tiles
//-----------------------------
function DeleteTiles() {
	for (var i = 0; i < countX * countZ - 1; i++) {
		Destroy(GameObject.FindWithTag("TILE" + i));
	}
}

//-----------------------------
// Save Stage
//-----------------------------
function SaveStage() {
	state = STATE.WAIT;
	var msg = "Game Saved...";
	
	// File Create
	var fileName = "gamesave.txt";		// 파일명
	try {
		var stream : StreamWriter = new StreamWriter(fileName);

		// 데이터 기록
		var nTime : int = Time.time - stageTime;	// 현재까지 경과 시간
		stream.WriteLine(stageNum);					// 스테이지 번호
		stream.WriteLine(nTime); 					// 스테이지 경과 시간
		stream.WriteLine(moveCount);				// 타일 이동 횟수
		stream.WriteLine(picNum);					// 이미지 번호

		// 배열 저장
		for (var i = 0; i < countX * countZ; i++) {
			stream.WriteLine(arTiles[i]);	
		}
		stream.Flush();
		stream.Close();
	} catch (err) {
		msg = "File save failed...";
	}
	
	state = STATE.IDLE;
	
	// 메시지 표시
	for (i = 1; i < 3; i++) {
		txtMsg.text = msg;
		yield WaitForSeconds(0.5);
		txtMsg.text = "";
		yield WaitForSeconds(0.5);
	}
}

//-----------------------------
// Load Stage
//-----------------------------
function LoadStage() {
	state = STATE.IDLE;
	var msg = "Game Loaded...";
	
	// File Open
	var fileName = "gamesave.txt";		// 파일명
	try {
		var stream = new File.OpenText(fileName);
		stageNum = int.Parse(stream.ReadLine());
		stageTime = Time.time - int.Parse(stream.ReadLine());
		moveCount = int.Parse(stream.ReadLine());	// 타일 이동 횟수
		picNum = int.Parse(stream.ReadLine());		// 이미지 번호
		
		DeleteTiles();		// 현재 타일 제거
		
		var loop = arPicCountX[stageNum] * arPicCountZ[stageNum];
		for (var i = 0; i < loop; i++) {
			arTiles[i] = int.Parse(stream.ReadLine());		// 배열 읽기	
		}
		stream.Close();
		
		MakeStage();
	} catch (err) {
		// 타일이 없으면 새로 시작
		if (CalcPoint(-1) == -9) {		
			state = STATE.START;
			return;
		}
		
		msg = "File not found...";
	}		
	
	state = STATE.IDLE;

	// 메시지 표시
	for (i = 1; i < 3; i++) {
		txtMsg.text = msg;
		yield WaitForSeconds(0.5);
		txtMsg.text = "";
		yield WaitForSeconds(0.5);
	}
}

//-----------------------------
// OnGUI
//-----------------------------
function OnGUI() {
	GUI.skin = skin;

	var w = Screen.width;		// 화면의 폭
	var h = Screen.height;		// 화면의 높이
	
	// 썸네일 표시
	var img : Texture2D = Resources.Load("picture" + picNum, Texture2D);	
	GUI.DrawTexture(Rect(5, h - 87, 60, 82), img);
	
	// 시간 계산
	var sec : int = Time.time - stageTime;
	var hour : int = sec / 3600;
	var min = (sec % 3600) / 60;
	sec = sec % 60; 
	
	txtMove.text = "Move = " + moveCount;
	txtStage.text = "Stage = " + stageNum;
	txtTime.text = "Time = " + hour + ":" + min + ":" + sec;
					
	var OnOff = "On";
	if (isSound) 
		OnOff = "Off";
		
	// 사운드 On/Off
	if (GUI.Button(Rect(w - 120, h - 165, 110, 35), "Sound " + OnOff)) {
		isSound = !isSound;
		audio.mute = !audio.mute;
	}	
	
	// Save & Load
	if (GUI.Button(Rect(w - 120, h - 125, 110, 35), "Save Game"))
		state = STATE.SAVE;
	if (GUI.Button(Rect(w - 120, h - 85, 110, 35), "Load Game"))
		state = STATE.LOAD;

	// Quit	
	if (GUI.Button(Rect(w - 120, h - 45, 110, 35), "Quit Game")) {
		DeleteTiles();		// 현재 타일 제거
		Application.LoadLevel("GameTitle");
	}	
}

