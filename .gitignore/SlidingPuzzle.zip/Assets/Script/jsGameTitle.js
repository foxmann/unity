#pragma strict

var skin : GUISkin;

//-----------------------------
// Start
//-----------------------------
function Start() {
	audio.mute = !jsManager.isSound;
}

//-----------------------------
// OnGUI()
//-----------------------------
function OnGUI() {
	GUI.skin = skin;

	var w = Screen.width / 2;
	var h = Screen.height / 2;
	
	var menuNum : int;
	
	if (GUI.Button(Rect(w - 70, h - 90, 140, 35), "New Game")) menuNum = 1;
	if (GUI.Button(Rect(w - 70, h - 40, 140, 35), "Load Game")) menuNum = 2;
	if (GUI.Button(Rect(w - 70, h + 10, 140, 35), "Options")) menuNum = 3;
	if (GUI.Button(Rect(w - 70, h + 60, 140, 35), "About")) menuNum = 4;
	if (GUI.Button(Rect(w - 70, h + 110, 140, 35), "Quit")) menuNum = 5;

	switch (menuNum) {
		case 1 :	// New Game
			jsManager.state = STATE.START;
			Application.LoadLevel("GameMain");
			break;
		case 2 :	// Load Game
			jsManager.state = STATE.LOAD;
			Application.LoadLevel("GameMain");
			break;
		case 3 :	// Options
			Application.LoadLevel("GameOptions");
			break;
		case 4 :	// About
			Application.LoadLevel("GameAbout");
			break;
		case 5 :	// Quit
			Application.Quit();
			break;
	}
}

