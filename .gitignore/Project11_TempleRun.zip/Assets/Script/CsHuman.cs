using UnityEngine;
using System.Collections;

public class CsHuman : MonoBehaviour {
	
	public GUISkin skin;		// GUI Skin
		
	GameObject manager;			// Bridge Manager
	
	int speedForward = 12;		// 전진 속도 
	int speedSide = 6;			// 옆걸음 속도 
	int jumpPower = 250;		// Jump Power	
	
	bool canJump = true;		// 점프가 가능한가?
	bool canTurn = false;		// 회전이 가능한가?
	bool canLeft = true;		// 왼쪽으로 이동이 가능한가?
	bool canRight = true;		// 오른쪽으로 이동이 가능한가?

	bool isGround = true;		// 주인공이 현재 바닥에 있는가?
	bool isDead = false;		// 사망?
	
	float dirX = 0;				// 좌우 이동 방향 -1:왼쪽, 1:오른쪽 
	float score = 0;
	
	Vector3 touchStart;			// Mobile 기기의 Touch 시작 위치 
	
	//----------------------
	// Start
	//----------------------
	void Start () {
		Screen.orientation = ScreenOrientation.Portrait;
		Screen.sleepTimeout = SleepTimeout.NeverSleep;
		
		manager = GameObject.Find("BridgeManager");
	}
	
	//----------------------
	// Start
	//----------------------
	void Update () {
		if (isDead) return;
		
		if (Input.GetKeyDown(KeyCode.Escape)) {
			Application.Quit();
		}	
		
		CheckMove();
		MoveHuman();
		
		score += Time.deltaTime * 1000;
	}
	
	//----------------------
	// CheckMove
	//----------------------
	void CheckMove () {
		RaycastHit hit;
		
		// down - 주인공이 다리 위에 있는가?
		isGround = true;
		if (Physics.Raycast(transform.position, Vector3.down, out hit, 2f)) {
			if (hit.transform.tag == "BRIDGE") {
				isGround = true;
			}
		}

		// left - 왼쪽으로 이동 가능한가?
		canLeft = true;
		if (Physics.Raycast(transform.position, -transform.right, out hit, 0.7f)) {
			if (hit.transform.tag == "GUARD") {
				canLeft = false;
			}
		}	
		
		// right - 오른쪽으로 이동 가능한가?
		canRight = true;
		if (Physics.Raycast(transform.position, transform.right, out hit, 0.7f)) {
			if (hit.transform.tag == "GUARD") {
				canRight = false;
			}
		}	
	}
	
	//----------------------
	// Move Human
	//----------------------
	void MoveHuman () {
		dirX = 0;		// 좌우 이동 방향 (왼쪽:-1, 오른쪽:1)
		
		// Mobile
		if (Application.platform == RuntimePlatform.Android ||
			Application.platform == RuntimePlatform.IPhonePlayer) {
			CheckMobile();
		} else {
			CheckKeyboard();	
		}

		// 이동 방향 설정 
		Vector3 moveDir = new Vector3(dirX * speedSide, 0, speedForward);
		transform.Translate(moveDir * Time.smoothDeltaTime);
	}
		
	//----------------------
	// 모바일 기기 조사 
	//----------------------
	void CheckMobile () {
		// 중력 가속도계 읽기 
		float x = Input.acceleration.x;
		
		// 좌우 이동 속도를 줄인다. 
		if (x < -0.2f && canLeft && isGround) dirX = -0.6f; 
		if (x > 0.2f && canRight && isGround) dirX = 0.6f; 
			
		// 모든 Touch에 대해서 조사 
		foreach (Touch tmp in Input.touches) {
			// Touch 시작 위치 설정 
			if (tmp.phase == TouchPhase.Began) {
				touchStart = tmp.position;	
			}
				
			// Touch Move - Touch 끝 위치 설정 
			if (tmp.phase == TouchPhase.Moved) {
				Vector3 touchEnd = tmp.position;	
					
				// Jump - 아래에서 위로 드래그했는가?
				if (isGround && canJump && touchEnd.y - touchStart.y > 100) {
					StartCoroutine("JumpHuman");	
				}
					
				// Turn Left - 왼쪽으로 드래그했는가 
				if (canTurn && touchEnd.x - touchStart.x < -100) {
					RotateHuman("LEFT");	
				}
					
				// Turn Right - 오른쪽으로 드래그했는가?
				if (canTurn && touchEnd.x - touchStart.x > 100) {
					RotateHuman("RIGHT");	
				}
			} // if
		} // for
	}	
		
	//----------------------
	// 키보드 조사 
	//----------------------
	void CheckKeyboard () {
		float key = Input.GetAxis("Horizontal");
		
		// 좌우 이동 방향 설정 
		if (key < 0 && canLeft && isGround) dirX = -1;
		if (key > 0 && canRight && isGround) dirX = 1;
			
		// Jump
		if (isGround && canJump && Input.GetKeyDown(KeyCode.Space)) {
			StartCoroutine("JumpHuman");	
		}
			
		// Turn
		if (canTurn) {
			if (Input.GetKeyDown(KeyCode.Q)) RotateHuman("LEFT");
			if (Input.GetKeyDown(KeyCode.E)) RotateHuman("RIGHT");
		}
	}	
		
	//----------------------
	// Jump
	//----------------------
	IEnumerator JumpHuman () {
		canJump = false;
		transform.rigidbody.AddForce(Vector3.up * jumpPower);
		animation.Play("jump_pose");
		
		yield return new WaitForSeconds(1);
		animation.Play("run");
		canJump = true;
	}
	
	//----------------------
	// Rotate
	//----------------------
	void RotateHuman (string sDir) {
		canTurn = false;	// 중복 회전 금지 
		
		// 현재의 회전 각도 구하기 
		Vector3 rot = transform.eulerAngles;
		
		switch (sDir) {
		case "LEFT" : rot.y -= 90; break;	
		case "RIGHT" : rot.y += 90; break;	
		}
		
		// 회전 각도 설정 
		transform.eulerAngles = rot;
		
		// 주인공 방향으로 다리 만들기 
		manager.SendMessage("MakeBridge", sDir, SendMessageOptions.DontRequireReceiver);
	}
	
	//----------------------
	// 충돌 - DeadZone
	//----------------------
	void OnCollisionEnter (Collision coll) {
		if (coll.transform.tag == "DEAD") {
			isDead = true;
			animation.Play("idle");
		}
	}	
	
	//----------------------
	// 충돌 - 기타 
	//----------------------
	void OnTriggerEnter (Collider coll) {
		switch (coll.transform.tag) {
		case "TURN" :
			canTurn = true;
			break;
		case "COIN" :
			score += 1000;
			Destroy(coll.gameObject);
			break;
		}
	}
	
	//----------------------
	// 충돌 끝 
	//----------------------
	void OnTriggerExit (Collider coll) {
		if (coll.tag == "TURN") {
			canTurn = false;	
		}
	}
	
	//----------------------
	// GUI
	//----------------------
	void OnGUI () {
		GUI.skin = skin;
		
		string str = "<size=20><color=#ffffff>Score : ##</Color></size>";
		GUI.Label(new Rect(10, 10, 300, 80), str.Replace("##", "" + (int) score));
		
		if (!isDead) return;
		animation.Play("idle");
		
		int w = Screen.width / 2;
		int h = Screen.height / 2;
		
		if (GUI.Button(new Rect(w - 60, h - 50, 120, 50), "Play Game")) {
			Application.LoadLevel("MainGame");	
		}
		
		if (GUI.Button(new Rect(w - 60, h + 50, 120, 50), "Quit Game")) {
			Application.Quit();
		}
	}
}
