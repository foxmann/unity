using UnityEngine;
using System.Collections;

public class CsCard : MonoBehaviour {
	
	int imgNum = 1;			// 이미지 번호 
	
	bool isOpen = false;
		
	//--------------------------------
	// Game Loop 
	//--------------------------------
	void Update () {
		// Touch 처리 
		if (Input.GetButtonDown("Fire1") && CsManager.state == CsManager.STATE.IDLE) {
			CheckCard();
		}	
		
		// 카드 진동 애니메이션 
		if (!isOpen && !animation.isPlaying) {
			if (Random.Range(0, 1000) > 998) {
				animation.Play("aniVibe");	
			}
		}
	}
	
	//--------------------------------
	// Card Check
	//--------------------------------
	void CheckCard() {
		RaycastHit hit;
		Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
		
		if (Physics.Raycast(ray, out hit, Mathf.Infinity)) {
			// Tag 읽기 
			string tag = hit.transform.tag;	
			if (tag.Substring(0, 4) == "CARD") {
				hit.transform.SendMessage("OpenCard", SendMessageOptions.DontRequireReceiver);
			}	
		}
	}
	
	//--------------------------------
	// Card Open - 외부 호출 
	//--------------------------------
	void OpenCard () {
		if (isOpen) return;		// 열린 카드는 처리할 내용 없음
		isOpen = true;			// 열린 카드로 설정 
		
		// 사운드 
		AudioSource.PlayClipAtPoint(Resources.Load("Sounds/click") as AudioClip, 
							transform.position);
		
		// 카드 번호 
		int cardNum = int.Parse(transform.tag.Substring(4));
		
		// 이미지 번호 
		imgNum = (cardNum + 1) / 2;
		animation.Play("aniOpen");	// 카드 오픈 애니메이션 실행
		
		// Game Manager에 통지 
		CsManager.cardNum = cardNum;
		CsManager.state = CsManager.STATE.HIT;
	}
	
	//--------------------------------
	// Card Close - 외부 호출 
	//--------------------------------
	void CloseCard () {
		animation.Play("aniClose");
		isOpen = false;
	}
	
	//--------------------------------
	// Animation Event	
	//--------------------------------
	void ShowImage () {
		transform.renderer.material.mainTexture = Resources.Load("card" + imgNum) as Texture2D;
	}
	
	//--------------------------------
	// Animation Event	
	//--------------------------------
	void HideImage () {
		transform.renderer.material.mainTexture = Resources.Load("back" + CsManager.stageNum) as Texture2D;
	}
	
}
