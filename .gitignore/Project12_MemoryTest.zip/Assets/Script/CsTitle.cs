﻿using UnityEngine;
using System.Collections;

public class CsTitle : MonoBehaviour {
	
	public GUISkin skin;
	
	bool isAbout = false;

	//---------------------------
	// 게임 초기화 
	//---------------------------
	void Start () {
		// Mobile 설정 
		Screen.orientation = ScreenOrientation.LandscapeRight;
		Screen.sleepTimeout = SleepTimeout.NeverSleep;
	}
	
	//---------------------------
	// GUI
	//---------------------------
	void OnGUI () {
		GUI.skin = skin;
		
		// 화면의 중심
		int w = Screen.width / 2;
		int h = Screen.height / 2;

		// 게임의 배경 - GUI Box
		Rect rect = new Rect(w * 0.35f, h * 0.2f, w * 1.3f, h * 1.6f);
		GUI.Box(rect, "");
		
		// About 표시중인가?
		if (isAbout) {
			ShowAbout();
			return;
		}
		
		// 글자1 
		rect = new Rect(w * 0.2f, h * 0.15f, w * 0.9f, h * 0.25f);
		GUI.DrawTexture(rect, Resources.Load ("imgTitle1") as Texture2D);
		
		// 글자2 
		rect = new Rect(w * 0.6f, h * 0.4f, w * 0.8f, h * 0.35f);
		GUI.DrawTexture(rect, Resources.Load ("imgTitle2") as Texture2D);
		
		// Button1
		if (GUI.Button (new Rect(w - 80, h - 50, 160, 56), "New Game")) {
			Application.LoadLevel("MainGame");	
		}
	
		// Button2
		if (GUI.Button (new Rect(w - 80, h + 20, 160, 56), "About Game")) {
			isAbout = true;
		}
	
		// Button3
		if (GUI.Button (new Rect(w - 80, h + 90, 160, 56), "Quit Game")) {
			Application.Quit();	
		}
	}
	
	//---------------------------
	// About
	//---------------------------
	void ShowAbout () {
		// 화면의 중심
		int w = Screen.width / 2;
		int h = Screen.height / 2;
		
		// Box 영역 설정
		Rect rect = new Rect(w * 0.35f, h * 0.2f, w * 1.3f, h * 1.6f);
		
		// Box 영역을 가상의 절대 좌표로 설정
		GUI.BeginGroup(rect);
		int x = 40;
		int y = 20;
		
		// 단말기 크기에 따른 글자 크기 설정 
		skin.label.fontSize = (int) (h * 0.12f);
		
		string str = "이 게임은 jPub 출판사에서 발행한 " + 
					 "UNITY3D 게임 만들기의 예제로 사용한 것으로,\n" + 
					 "이 책의 독자들은 필자의 허락없이 " +
					 "게임의 Source를 임의로 복사 또는 변경해서" +
					 "사용할 수 있습니다.";
		
		GUI.Label (new Rect(x, y, w * 1, h * 1.2f), str);
		
		GUI.EndGroup();		// BeginGroup 끝 
						
		// Close Button
		if (GUI.Button (new Rect(w - 70, h * 1.6f, 140, 50), "Close")) {
			isAbout = false;
		}
	}
}
