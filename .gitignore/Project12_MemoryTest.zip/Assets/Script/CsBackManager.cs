﻿using UnityEngine;
using System.Collections;

public class CsBackManager : MonoBehaviour {
	
	Transform back1;			// 배경 이미지1
	Transform back2;			// 배경 이미지2
	
	int delayTime = 10;			// 오버랩 지연 시간 
	float currentTime = 0;		// 현재의 시간 
	
	int imgCnt = 6;				// 배경 이미지 개수 
	int imgNum = 1;				// 현재의 이미지 번호 
	
	//----------------------------
	// 게임 초기화 
	//----------------------------
	void Start () {
		// 배경 찾기 
		back1 = transform.Find("배경1");		
		back2 = transform.Find("배경2");
	}
	
	//----------------------------
	// 게임 루프 
	//----------------------------
	void Update () {
		currentTime += Time.deltaTime;			// 지연 시간 처리 

		if (currentTime >= delayTime) {
			currentTime = 0;							
			StartCoroutine("OverlapImage");	// 이미지 오버랩 
		}	
	}
	
	//----------------------------
	// 이미지 오버랩
	//----------------------------
	IEnumerator OverlapImage () { 
		// 이미지의 Alpha 설정 
		for (float alpha = 1; alpha >= 0; alpha -= 0.015f) {
			back1.renderer.material.color = new Vector4(1, 1, 1, alpha);
			back2.renderer.material.color = new Vector4(1, 1, 1, 1 - alpha);
			
			// 화면 갱신까지 대기 
			yield return new WaitForFixedUpdate();
		}
		
		// 배경 바꾸기 
		Transform tmp = back1;
		back1 = back2;
		back2 = tmp;
		
		// 다음 이미지 준비
		imgNum = (int) Mathf.Repeat(++imgNum, imgCnt);
		back2.renderer.material.mainTexture = 
					Resources.Load("imgBack" + imgNum) as Texture2D;
		
		currentTime = 0;							
	}
}
