using UnityEngine;
using System.Collections;

public class CsManager : MonoBehaviour {
	
	GUIText txtTotalTime;			// GUI Text
	GUIText txtStageTime;
	GUIText txtStage;
	GUIText txtHit;
	GUIText txtStageNum;
	
	static public int cardNum;		// Click한 카드 번호
	int lastNum = 0;				// 직전의 카드 번호 
	
	int cardCnt;					// 스테이지의 전체 카드 수 
	static public int hitCnt = 0;	// 카드 클릭 횟수 
	
	static public int stageNum = 1;	// 스테이지 번호 
	int stageCnt = 6;				// 전체 스테이지 수 
	
	int[] arCards = new int[33];	// 카드 배열 - 카드 섞기용 
	
	float startTime;				// 게임 시작 시각 
	float stageTime;				// 스테이지 경과 시간 
	
	public enum STATE {START, HIT, WAIT, IDLE, CLEAR};
	static public STATE state = STATE.START;
	

	//----------------------------
	// 게임 초기화  
	//----------------------------
	void Start () {
		// 게임 시간 초기화 
		startTime = stageTime = Time.time;

		// GUI Text 찾기 
		txtTotalTime = GameObject.Find("txtTotalTime").guiText;
		txtStageTime = GameObject.Find("txtStageTime").guiText;
		txtStage = GameObject.Find("txtStage").guiText;
		txtHit = GameObject.Find("txtHit").guiText;
		txtStageNum = GameObject.Find("txtStageNum").guiText;
	}
	
	//----------------------------
	// 게임 루프
	//----------------------------
	void Update () {
		switch (state) {
		case STATE.START :
			StartCoroutine("MakeStage");	// 스테이지 만들기 
			break;
		case STATE.HIT :
			CheckCard();
			break;
		case STATE.CLEAR :
			StartCoroutine("StageClear");
			break;
		}	
		
		if (Input.GetKeyDown(KeyCode.Escape)) {
			Application.Quit();
		}
		
		print (state);
	}
	
	//----------------------------
	// 스테이지 만들기 
	//----------------------------
	IEnumerator MakeStage () {
		state = STATE.WAIT;					// 현재 작업중으로 설정 
		
		// 스테이지 번호 표시
		StartCoroutine("ShowStageNum");
		
		float sx = 0; 						// 시작 카드의 x좌표
		float sz = 0;						// 시작 카드의 z좌표
		
		SetCardPos(out sx, out sz);			// 시작 카드 위치 계산 
		ShuffleCard(); 						// 카드 섞기 
		
		int n = 1;							// 시작 카드 번호 

		// 카드 배열 읽기 
		string[] str = CsStage.stage[stageNum - 1];
		
		// 배열의 행의 수만큼 반복 
		foreach (string t in str) {					
			// 각 행의 문자열을 단일 문자 배열로 변환(문자열 좌우의 공백 제거) 
			char[] ch = t.Trim().ToCharArray();		
			
			float x = sx;		// 카드의 x축 좌표 
			
			// 1행의 문자열 길이만큼 반복
			foreach (char c in ch) {
				switch (c) {
				case '*' : 
					// 카드 만들기 
					GameObject card = Instantiate(Resources.Load("Prefab/Card")) as GameObject;
					card.transform.position = new Vector3(x, 0, sz);	// 카드 좌표 설정
					card.renderer.material.mainTexture = Resources.Load("back" + stageNum) as Texture2D;

					// card.tag = "CARD" + n++;				// 태그 달기 - 일련 번호 
					card.tag = "CARD" + arCards[n++];	// 섞인 카드  
					x++;
					break;
				case '.' :		// 빈 칸 처리
					x++;
					break;
				case '>' :		// 반칸 공백 처리 
					x += 0.5f;
					break;
				case '^' :		// 반 줄 행간 처리
					sz += 0.5f; 
					break;
				} // switch	
				
				if (c == '*') {
					yield return new WaitForSeconds(0.03f);
				}	
				
			} // for ch
			
			sz--;				// 한 줄 아래로 이동
		} // for str	
		
		state = STATE.IDLE;		// 입력 대기중으로 전환 
	} 
	
	//--------------------------------
	// 카드의 시작 위치 계산
	//--------------------------------
	void SetCardPos(out float sx, out float sz) {	
		float x = 0;		// 가로 카드 수(반 칸 공백 포함)
		float z = 0;		// 세로 행 수 (반줄 행간 포함)	
		
		float maxX = 0;		// 가로 카드 최대 수 
		cardCnt = 0;		// 스테이지 전체 카드 수  	
		
		// 카드 배열 조사 
		string[] str = CsStage.stage[stageNum - 1];
		
		// 행의 수만큼 반복 
		for (int i = 0; i < str.Length; i++) {
			string t = str[i].Trim();		// 1행 읽기 
			x = 0;		
			
			// 각 행의 글자 수만큼 반복 
			for (int j = 0; j < t.Length; j++) {
				switch (t[j]) {
				case '.' :
				case '*' :
					x++;
					if (t[j] == '*') cardCnt++;		// 전체 카드 개수 
					break;
				case '>' :
					x += 0.5f;
					break;
				case '^' :
					z -= 0.5f;
					break;
				} // switch
			} // for j
			
			// 각 행의 최대 카드 수 계산 
			if (x > maxX) maxX = x;		
			
			z++;				// 전체 행의 수 
		} // for i
		
		sx = -maxX / 2;			// 카드 시작 위치 계산 
		sz = (z - 1) / 2;	
		
		print (cardCnt);		// 전체 카드 수 디버그 출력 
	}


	//--------------------------------
	// 카드 섞기
	//--------------------------------
	void ShuffleCard () {	
		// 배열 초기화 
		for (int i = 1; i <= cardCnt; i++) {
			arCards[i] = i;
		}
		
		// return;	// 임시로 카드를 섞지 않는다 
		
		// 카드 섞기 - 15회 정도 반복 
		for (int i = 1; i <= 15; i++) {
			int n1 = Random.Range(1, cardCnt + 1);	
			int n2 = Random.Range(1, cardCnt + 1);	
			
			// 교환 
			int t = arCards[n1];
			arCards[n1] = arCards[n2];
			arCards[n2] = t;
		}
	}
	
	//--------------------------------
	// 카드 판정
	//--------------------------------
	void CheckCard () {	
		state = STATE.WAIT;
		
		// 첫 번째 카드 
		if (lastNum == 0) {
			lastNum = cardNum;		// 현재 카드 보존 
			state = STATE.IDLE;		// IDLE 상태로 전환 
			return;
		}
		
		// 이미지 찾기 
		int img1 = (cardNum + 1) / 2;	// 이미지 번호 
		int img2 = (lastNum + 1) / 2;
		
		// 다른 카드? 
		if (img1 != img2) {
			// 카드 닫기 
			StartCoroutine("CloseTwoCards");	
			
			lastNum = 0;		
			state = STATE.IDLE;
			return;
		}
		
		// 같은 카드? 
		hitCnt += 2;			// 열린 카드 수	
		
		// 스테이지 Clear?
		if (hitCnt == cardCnt) {
			state = STATE.CLEAR;
			return;
		}
		
		// 사운드 재생 
		AudioSource.PlayClipAtPoint(Resources.Load("Sounds/hit") as AudioClip, transform.position);
		
		lastNum = 0;
		state = STATE.IDLE;
	}
	
	//--------------------------------
	// 카드 닫기 
	//--------------------------------
	IEnumerator CloseTwoCards () {	
		// Tag로 카드 찾기 
		GameObject card1 = GameObject.FindWithTag("CARD" + lastNum);
		GameObject card2 = GameObject.FindWithTag("CARD" + cardNum);
		
		while (card2.animation.isPlaying) {
			// Open 애니메이션이 끝날 때까지 대기 
			yield return new WaitForFixedUpdate();
		}
		
		// 카드 닫기 
		card1.SendMessage("CloseCard", SendMessageOptions.DontRequireReceiver);
		card2.SendMessage("CloseCard", SendMessageOptions.DontRequireReceiver);
	}
	
	//--------------------------------
	// 스테이지 Clear
	//--------------------------------
	IEnumerator StageClear () {
		state = STATE.WAIT;
		
		// 팡파르 표시 
		GameObject fanfare = Instantiate(Resources.Load ("Prefab/Fanfare")) as GameObject;
		fanfare.transform.position = new Vector3(0, 0.5f, 0);
		
		// 사운드 재생 
		AudioSource.PlayClipAtPoint(Resources.Load("Sounds/fanfare") as AudioClip,
							transform.position);
		
		yield return new WaitForSeconds(2);
		
		// 스테이지의 카드 제거 
		for (int i = 1; i <= cardCnt; i++) {
			GameObject card = GameObject.FindWithTag("CARD" + i);
			Destroy(card);
		}	
		
		// 다음 스테이지 번호 
		++stageNum;
		if (stageNum > stageCnt) {
			// 게임 타이틀 씬으로 전환 
			Application.LoadLevel("GameTitle");
			yield return null;
		}
		
		// 스테이지 초기화 
		stageTime = Time.time;
		lastNum = 0;
		hitCnt = 0;
		
		state = STATE.START;
	}

	//--------------------------------
	// 스테이지 번호 표시 
	//--------------------------------
	IEnumerator ShowStageNum () {
		// 스테이지 번호 
		txtStageNum.text = "STATE " + stageNum;
		
		// 글자 색 설정 - 옅은 노랑 
		txtStageNum.material.color = new Vector4(1, 1, 0.6f, 1);
		
		for (int i = 1; i <= 180; i += 3) {
			// 글자 크기를 점점 키운다.
			txtStageNum.fontSize = i;
			
			// 화면 처리가 끝날 때까지 대기 
			yield return new WaitForFixedUpdate();
		}
		
		// 0.5초 대기 
		yield return new WaitForSeconds(0.5f);
		
		// 글자의 투명도 낮추기 		
		for (float alpha = 1; alpha >= 0; alpha -= 0.02f) {
			// 글자 색 
			txtStageNum.material.color = new Vector4(1, 1, 0.6f, alpha);
			
			// 화면 처리가 끝날 때까지 대기 
			yield return new WaitForFixedUpdate();
		}
		
		// 글자 지우기 
		txtStageNum.text = "";	
	}
	
	//--------------------------------
	// OnGUI
	//--------------------------------
	void OnGUI () {
		// 시간 계산 
		int time1 = (int) (Time.time - startTime);	
		int time2 = (int) (Time.time - stageTime);	
		
		// 표시 
		txtTotalTime.text = "Total Time : " + time1;
		txtStageTime.text = "Stage Time : " + time2;
		txtStage.text = "Stage : " + stageNum;
		txtHit.text = "Hit : " + hitCnt;
	}
}
		