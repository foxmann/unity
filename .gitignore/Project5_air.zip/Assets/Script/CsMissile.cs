using UnityEngine;
using System.Collections;

public class CsMissile : MonoBehaviour {
	
	int speed = 20;

	//--------------------------------
	// 미사일 이동 
	//--------------------------------
	void Update ()
	{
		float amtMove = speed * Time.smoothDeltaTime;
		transform.Translate(Vector3.forward * amtMove);
		
		if (transform.position.z > 35) {
			Destroy(gameObject);	
		}
	}
	
	//--------------------------------
	// 충돌 처리
	//--------------------------------
	void OnTriggerEnter (Collider coll)
	{
		if (coll.transform.tag == "ASTEROID") {
			coll.SendMessage("HitMissile", transform.position, 
				SendMessageOptions.DontRequireReceiver);	
			
			Destroy(gameObject);
		}
	}
}
