using UnityEngine;
using System.Collections;

public class CsSky : MonoBehaviour {
	
	float speed = 0.4f;		// 스크롤 속도 
	
	// 배경화면 스크롤 
	void Update ()
	{
		float ofs = speed * Time.time;	
		transform.renderer.material.mainTextureOffset = new Vector2(0, -ofs);
	}
}
