﻿using UnityEngine;
using System.Collections;

public class CsAsteroid : MonoBehaviour {
	
	public Transform expSmall;	// 폭파 불꽃 작은 것 
	public Transform expBig;	// 폭파 불꽃 큰 것 
	public AudioClip sndExp;	// 폭파 사운드 
	
	int speed;		// 이동 속도 
	int rotX;		// 회전 속도 
	int rotY;
	int rotZ;
	
	int HP;			// 견고함 

	//----------------------------
	// 운석 초기화 
	//----------------------------
	void Start ()
	{
		InitAsteroid();
	}
	
	//----------------------------
	void Update ()
	{
		float amtMove = speed * Time.smoothDeltaTime;
		
		transform.Rotate(new Vector3(rotX, rotY, rotZ) * Time.smoothDeltaTime);
		transform.Translate(Vector3.back * amtMove, Space.World);
		
		if (transform.position.z < -11) {
			Destroy(gameObject);	
		}
	}
	
	//----------------------------
	// 미사일과 충돌 
	//----------------------------
	void HitMissile (Vector3 pos)
	{
		// 작은 불꽃 표시 
		CsFighter.score += 100;
		Instantiate(expSmall, pos, Quaternion.identity);	
		AudioSource.PlayClipAtPoint(sndExp, transform.position);	// 사운드 
		
		HP--;
		if (HP < 0) {
			DestroySelf();
		}
	}
	
	//----------------------------
	// 운석 폭파
	//----------------------------
	void DestroySelf ()
	{
		// 큰 불꽃 표시 
		CsFighter.score += 1000;
		Instantiate(expBig, transform.position, Quaternion.identity);
		AudioSource.PlayClipAtPoint(sndExp, transform.position);	// 사운드 
		Destroy(gameObject);
	}
	
	//----------------------------
	// 운석 초기화 
	//----------------------------
	void InitAsteroid ()
	{
		// 운석의 크기 설정 
		float sizeX = Random.Range(1.5f, 2.5f);
		float sizeY = Random.Range(1.5f, 2.5f);
		float sizeZ = Random.Range(1.5f, 2.5f);
		transform.localScale = new Vector3(sizeX, sizeY, sizeZ);
				
		// 운석의 Color 설정 
		float r = Random.Range(0.6f, 1);
		transform.renderer.material.color = new Vector4(r, 0.8f, 0.8f, 1);
		
		// 운석의 속도 및 HP 설정 
		speed = Random.Range(10, 20);	
		HP = Random.Range(0, 5);	
		
		// 운석의 회전속도 설정 
		rotX = Random.Range(-90, 90);	
		rotY = Random.Range(-90, 90);	
		rotZ = Random.Range(-90, 90);	

		
		// 운석의 초기 위치 
		float x = Random.Range(-28, 28);	
		float z = Random.Range(37, 45);	
		transform.position = new Vector3(x, 0, z);
	}
}
