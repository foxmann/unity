using UnityEngine;
using System.Collections;

public class CsFighter : MonoBehaviour {
	
	public GUISkin skin;				// GUI Skin
	
	public Transform asteroid;			// 운석 
	public Transform missile;			// 미사일 프리팹 
	public Transform expBig;			// 폭파 불꽃 큰 것 
	public AudioClip sndMissile;		// 미사일 발사 사운드 
	
	Transform LPoint;					// spPoint Left 
	Transform RPoint;					// spPoint Right

	GameObject LFire;					// 왼쪽 불꽃 
	GameObject RFire;					// 오른쪽 불꽃 
	
	bool canFire = true;				// 미사일을 발사할 수 있는가?
	bool isDead = false;				// 전투기가 폭파되었는가?
	
	int HP = 10;						// 전투기 보호막 
	static public int score = 0;		// 점수
	int speed = 20;						// 스피드 
	float fw = Screen.width * 0.08f;	// 전투기의 폭 
	
	//--------------------------------
	// 게임 초기화 
	//--------------------------------
	void Start ()
	{
		LPoint = transform.Find("LPoint");
		RPoint = transform.Find("RPoint");
		
		LFire = transform.Find("LFire").gameObject;
		RFire = transform.Find("RFire").gameObject;
		
		LFire.SetActive(false);
		RFire.SetActive(false);
		//LFire.renderer.enabled = false;
		//RFire.renderer.enabled = false;
		
		HP = 5;
		score = 0;
		isDead = false;
	}
	
	//--------------------------------
	// 게임 루프 
	//--------------------------------
	void Update ()
	{
		// if (isDead) return;
		
		MoveFighter();		// 전투기 이동 
		ShootMissile();		// 미사일 발사 
		MakeAsteroid();		// 운석 만들기 
	}
	
	//--------------------------------
	// 전투기 이동 
	//--------------------------------
	void MoveFighter () 
	{
		float amtMove = speed * Time.smoothDeltaTime;
		float key = Input.GetAxis("Horizontal");
		
		// 전투기의 월드 좌표를 스크린 좌표로 변환 
		Vector3 pos = Camera.main.WorldToScreenPoint(transform.position);
		
		if ((key < 0 && pos.x > fw) || (key > 0 && pos.x < Screen.width - fw)) {
			transform.Translate(Vector3.right * amtMove * key, Space.World);
		}	
		
		// 전투기 회전
		transform.eulerAngles = new Vector3(0, 0, -key * 20);
	}
	
	//--------------------------------
	// 미사일 발사 
	//--------------------------------
	void ShootMissile ()
	{
		if (Input.GetButton("Fire1") && canFire) {	
			StartCoroutine("MakeMissile");
		}
	}
	
	//--------------------------------
	// 미사일 만들기 
	//--------------------------------
	IEnumerator MakeMissile ()
	{
		canFire = false;	
		// 미사일 만들기 
		Instantiate(missile, LPoint.position, Quaternion.identity);
		Instantiate(missile, RPoint.position, Quaternion.identity);
		AudioSource.PlayClipAtPoint(sndMissile, transform.position);
		
		// LFire.renderer.enabled = true;
		// RFire.renderer.enabled = true;
		LFire.SetActive(true);
		RFire.SetActive(true);
		
		
		yield return new WaitForSeconds(0.2f);		// 0.2초 간격으로 미사일 발사 
		// LFire.renderer.enabled = false;
		// RFire.renderer.enabled = false;
		LFire.SetActive(false);
		RFire.SetActive(false);
		canFire = true;	
	}
	
	//--------------------------------
	// 운석 만들기 
	//--------------------------------
	void MakeAsteroid ()
	{
		if (Random.Range(0, 1000) > 980) {
			Instantiate(asteroid);
		}
	}
	
	//--------------------------------
	// 충돌 처리
	//--------------------------------
	void OnTriggerEnter (Collider coll)
	{
		if (coll.transform.tag == "ASTEROID") {
			// 운석 파괴 
			coll.SendMessage("DestroySelf", SendMessageOptions.DontRequireReceiver);
			
			HP--;
			if (HP <= 0) {
				StartCoroutine("DestroyFighter");
			}
		}
	}
	
	//--------------------------------
	// 전투기 파괴
	//--------------------------------
	IEnumerator DestroyFighter ()
	{
		Instantiate(expBig, transform.position, Quaternion.identity);
		yield return new WaitForSeconds(1);
		
		transform.position = new Vector3(0, -10, -20);	
		isDead = true;
	}
	
	//--------------------------------
	// OnGUI
	//--------------------------------
	void OnGUI ()
	{
		GUI.skin = skin;
		
		int w = Screen.width / 2;		// 화면의 중심 
		int h = Screen.height / 2;
		
		string sHp = "<color=yellow><b>HP : ##</b></color>";
		string sScore = "<color=#00ff00ff><b>Score : ##</b></color>";
		
		GUI.Label(new Rect(10, 10, 120, 50), sHp.Replace("##", HP.ToString()));
		GUI.Label(new Rect(w - 50, 10, 120, 50), sScore.Replace("##", "" + score));
		
		if (!isDead)
			return;
		
		if (GUI.Button(new Rect(w - 60, h - 50, 120, 50), "Play Game")) {
			Application.LoadLevel("MainGame");	
		}
		
		if (GUI.Button(new Rect(w - 60, h + 50, 120, 50), "Quit Game")) {
			Application.Quit();
		}
	}
}// end of class
