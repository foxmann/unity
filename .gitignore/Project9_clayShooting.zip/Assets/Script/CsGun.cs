﻿using UnityEngine;
using System.Collections;

public class CsGun : MonoBehaviour {
	
	public AudioClip sndFire;		// 총발사음 
	public AudioClip sndCocking;	// 실탄 장전음 
	public AudioClip sndStage;		// 배경음악 
	public AudioClip sndOver;		// 게임오버 음악 
	
	public GUISkin skin;			// GUI Skin
	public Transform clay;			// 접시 - 프리팹 
	public Transform bird;			// 참새 
	public Transform exp;			// 폭파 파티클 
	public Transform gunFire;		// 총구화염 파티클  
	public Transform fireLine;		// 발사한 총알 궤적 

	Transform bullet;				// 실탄(탄피) 
	Transform spPoint;				// Spawn Point

	static public int miss;			// 실패 횟수 
	int hit;						// 성공 횟수 
	int bulletCnt = 5;				// 남은 실탄수 

	float startTime, overTime;		// 시작시각, 종료시각 
	bool gameOver = false;			// 게임오버인가?
	
	int width, height;				// 화면의 폭과 높이 
	
	//--------------------------------
	// 게임 초기화 
	//--------------------------------
	void Start () {
		// Mobile 기기 설정 
		Screen.orientation = ScreenOrientation.LandscapeRight;
		Screen.sleepTimeout = SleepTimeout.NeverSleep;
		
		spPoint = transform.Find("spPoint");
		bullet = transform.Find("탄피");
		
		InitStage();
	}
	
	//--------------------------------
	// 게임 루프
	//--------------------------------
	void Update () {
		if (gameOver) return;
		
		// GameOver?
		if (miss >= 10) {
			gameOver = true;
			overTime = Time.time;
			return;
		}
		
		// Esc Key?
		if (Input.GetKeyDown(KeyCode.Escape)) {
			Application.Quit();	
		}
		
		RotateGun();
		MakeClay();
		
		// 왼쪽 버튼으로 발사 
		if (Input.GetButtonDown("Fire1")) {
			FireGun();
		}
		
		// 오른쪽 버튼으로 장전 
		if (bulletCnt < 5 && Input.GetMouseButtonDown(1)) {
			StartCoroutine("ChargeBullet");	
		}
	}
	
	//--------------------------------
	// 엽총 회전 
	//--------------------------------
	void RotateGun () {
		Vector3 pos = Input.mousePosition;
		
		// 화면을 벗어난 마우스 위치는 무시
		pos.x = Mathf.Clamp(pos.x, 0, Screen.width);
		pos.y = Mathf.Clamp(pos.y, 0, Screen.height);
		
		pos.z = 13.2f;				// 카메라로 부터의 거리 
		
		// 마우스 위치를 월드 좌표로 변환 
		Vector3 view = Camera.main.ScreenToWorldPoint(pos);
		transform.LookAt(view);		// 엽총 회전 
	}
	
	//------------------------------
	// 접시와 참새 만들기 
	//------------------------------
	void MakeClay ()
	{
		int rate = 30;		// 발생 확률 
		if (Random.Range(0, 1000) > rate || animation.isPlaying) {
			return;
		}
			
		if (Random.Range(0, 100) < 20) {
			Instantiate(bird);
		} else {
			GameObject[] obj = GameObject.FindGameObjectsWithTag("CLAY");
			if (obj.Length < 4) {
				Instantiate(clay);
			}	
		}	
	}
	
	//------------------------------
	// 실탄 발사
	//------------------------------
	void FireGun ()
	{
		// 실탄 장전 애니메이션 진행 중이면 발사 금지 
		if (bulletCnt <= 0 || animation.isPlaying && animation.name == "aniCharge") {	
			return;					// 발사하지 않음 
		}
		
		RaycastHit hit;				// 탐색 처리용 변수 
		
		// 카메라 시점에서 커서 위치 계산 
		Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition); 
		
		// 커서 방향으로 목표물 탐색 
		if (!Physics.Raycast(ray, out hit, Mathf.Infinity)) {
			return;
		}	
		
		// 총을 클릭하면 실탄 재장전(모바일 기기를 위함) 
		if (hit.transform.tag == "GUN" && bulletCnt < 5) {
			StartCoroutine("ChargeBullet");
			return;
		}	
		
		// 실탄 발사 
		Instantiate(fireLine, spPoint.position, spPoint.rotation);
		
		// 총구 앞에 화염 표시 
		Instantiate(gunFire, spPoint.position, Quaternion.identity);
		AudioSource.PlayClipAtPoint(sndFire, transform.position);
		
		animation.Stop();			// 애니메이션 중지 
		animation.Play("aniFire");	// 탄피 배출 애니매이션 실행 
		CheckTarget(hit);			// 명중인지 판정 
		
		// 남은 실탄 수 처리 
		bulletCnt--;
		if (bulletCnt <= 0) {
			StartCoroutine("ChargeBullet");	
		}	
	}

	//------------------------------
	// 목표물 적중 여부 판정 
	//------------------------------
	void CheckTarget (RaycastHit hit)
	{
		switch (hit.transform.tag) {
		case "CLAY":	
			this.hit++;
			// 접시 폭파 파티클 표시 
			Instantiate(exp, hit.transform.position, Quaternion.identity);
			Destroy(hit.transform.gameObject);
			break;
		case "BIRD":	
			// 새 위치에 작은 화염 표시 
			Instantiate(gunFire, hit.transform.position, Quaternion.identity);
			
			// 추락 중인 참새는 무시
			if (hit.transform.eulerAngles.z != 0) {
				return;
			}
			
			miss++;
			// 새의 추락 및 'Oops' 표시 메소드 실행 
			hit.transform.SendMessage("DeadBird", SendMessageOptions.DontRequireReceiver);
			break;
		}
	}
		
	//------------------------------
	// 탄약 재장전 
	//------------------------------
	IEnumerator ChargeBullet ()
	{
		// 탄피배출 애니메이션이 끝날 때까지 대기 
		while (animation.isPlaying) {
			yield return 0;
		}
		
		// 탄약 장전 애니메이션 실행 
		animation.Play("aniCharge");
		
		// 탄약 장전 애니메이션이 끝날때까지 대기 
		yield return new WaitForSeconds(0.5f);
		bulletCnt = 5;
	}

	//------------------------------
	// 실탄 장전음 - 애니메이션 이벤트 
	//------------------------------
	void PlaySoundCocking ()
	{
		AudioSource.PlayClipAtPoint(sndCocking, Vector3.zero);
	}
	
	//------------------------------
	// 실탄 보이기 - 애니메이션 이벤트  
	//------------------------------
	void ShowBullet ()
	{
		bullet.gameObject.renderer.enabled = true;
	}
	
	
	//------------------------------
	// 탄피 감추기 - 애니메이션 이벤트 
	//------------------------------
	void HideBullet ()
	{
		bullet.gameObject.renderer.enabled = false;
	}
	
	//------------------------------
	// 변수 초기화 
	//------------------------------
	void InitStage ()
	{
		Screen.showCursor = false;	// 커서 숨김 
		
		width = Screen.width;		// 화면의 폭 
		height = Screen.height;		// 화면의 높이 
		
		startTime = Time.time;
		overTime = 0;
		
		hit = miss = 0;
		bulletCnt = 5;
		gameOver = false;
		
		// 배경 음악 설정 
		audio.loop = true;
		audio.Play();
	}
	
	//------------------------------
	// 스코어 등 화면 표시 
	//------------------------------
	void OnGUI ()
	{
		GUI.skin = skin;
		float time = Time.time - startTime;	// 게임 진행 시간 
		
		if (!gameOver) {
			// 커서 위치에 조준점(Cross hair) 표시 
			float x = Input.mousePosition.x - 24;
			float y = height - Input.mousePosition.y - 24;
			GUI.DrawTexture(new Rect(x, y, 48, 48), Resources.Load("crossHair") as Texture2D);
		} else {
			time = overTime - startTime;
		}	
	
		// 남은 실탄수 표시 
		for (int i = 1; i <= bulletCnt; i++) {
			GUI.DrawTexture(new Rect(i * 12, height - 20, 8, 16), Resources.Load("bullet") as Texture2D);
		}
		
		// 점수 등 표시 
		string sHit = "<size='30'>HIT : " + hit + "</size>";
		string sMiss = "<size='30'>MISS : " + miss + "</size>";
		string sTime = "<color='yellow'><size='30'>Time : " + (int)time + "</size></color>";
		
		GUI.Label(new Rect(30, 20, 120, 40), sHit);
		GUI.Label(new Rect(width / 2 - 40, 20, 160, 40), sTime);
		GUI.Label(new Rect(width - 120, 20, 120, 40), sMiss);
		
		string msg = "Shoot : Left Btn,  Charge : Gun Click";
		GUI.Label(new Rect(width - 280, height - 40, 380, 40), msg);

		// 게임오버 처리 
		if (!gameOver) return;
		
		Screen.showCursor = true;		// 커서 보이기 
		if (audio.clip != sndOver) {
			audio.clip = sndOver;		// 게임오버 사운드 연주 
			audio.loop = false;
			audio.Play();
		}	
			
		// 버튼표시 및 처리 
		if (GUI.Button(new Rect(width / 2 - 70, height / 2 - 50, 140, 60), "Play Game")) {
			Application.LoadLevel("MainGame");	
		}	
			
		if (GUI.Button(new Rect(width / 2 - 70, height / 2 + 50, 140, 60), "Quit Game")) {
			Application.Quit();	
		}	
	}
} // end of class 
