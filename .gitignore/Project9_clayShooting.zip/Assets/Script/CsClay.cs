using UnityEngine;
using System.Collections;

public class CsClay : MonoBehaviour {

	float speed;			// 속도
	float rotZ;				// 회전각도
	float gravity;			// 추락 속도
	
	int dirX;				// 이동 방향
	
	//------------------------------
	// 초기 위치 설정
	//------------------------------
	void Start ()
	{
		SetPosition();
	}
	
	//------------------------------
	// 게임 루프 - 접시 이동
	//------------------------------
	void Update ()
	{
		// 접시 이동
		gravity -= 1.3f * Time.deltaTime;
		Vector3 move = new Vector3(speed * dirX, gravity, 0);
		transform.Translate(move * Time.smoothDeltaTime, Space.World);
		
		// 화면 밖인지 조사
		if (Mathf.Abs(transform.position.x) > 8 || transform.position.y < -3) {
			CsGun.miss++;
			Destroy(gameObject);
		}	
	}
	
	//------------------------------
	// 초기 위치 설정
	//------------------------------
	void SetPosition ()
	{
		speed = Random.Range(3, 5f);				// 이동 속도
		gravity = 2f;								// 추락 속도 
		dirX = (Random.Range(0, 2) == 0) ? -1 : 1;	// 이동 방향 (-1 or 1)
		
		float posX = -8 * dirX;						// 화면의 좌우 
		float posY = Random.Range(1.5f, 3);			// 접시의 높이 
		
		transform.position = new Vector3(posX, posY, 7);
		
		// 접시 회전 
		int x = Random.Range(20, 40);
		transform.eulerAngles = new Vector3(x, 0, 0);
	}
} // end of class 
