using UnityEngine;
using System.Collections;

public class CsBird : MonoBehaviour {

	public Transform oops;		// 프리팹		
		
	int frames = 6;				// 전체 이미지 수 
	int frmPerSec = 16;			// 1초에 표시할 이미지 수 
	
	float delayTime;			// 이미지 표시 간격
	int frmNum = 0; 			// 현재 표시할 이미지 번호
	float ofsX;					// 이미지의 Material Offset
	
	float speed;				// 이동 속도
	bool isDead = false;		// 죽었나?
	
	//------------------------------
	// 참새 위치 초기화
	//------------------------------
	void Start ()
	{
		SetPosition();
	}
	
	//------------------------------
	// 게임 루프 - 애니메이션 & 이동
	//------------------------------
	void Update ()
	{
		if (!isDead)
			AnimateBird();	
		
		float amtMove = speed * Time.smoothDeltaTime;
		
		if (!isDead)		// 날아갈 때는 오른쪽으로 이동
			transform.Translate(Vector3.right * amtMove, Space.World);
		else 				// 추락할 때는 아래로 이동
			transform.Translate(Vector3.down * amtMove * 2, Space.World);
		
		// 화면을 벗어나면 제거
		if (transform.position.x > 7 || transform.position.y < -3) {
			Destroy(gameObject);
		}
	}
	
	//------------------------------
	// 애니메이션
	//------------------------------
	void AnimateBird ()
	{
		delayTime -= Time.deltaTime;		// 지연 시간 감소	
		
		if (delayTime <= 0) {
			// 다음 이미지 표시 
			transform.renderer.material.mainTextureOffset = new Vector2(ofsX * frmNum, 0);
			
			frmNum = (int)Mathf.Repeat(++frmNum, frames);	// 다음 이미지 번호
			delayTime = 1f / frmPerSec;						// 지연 시간 설정
		}	
	}		
	
	//------------------------------
	// 참새 추락 - 외부 호출 
	//------------------------------
	void DeadBird ()
	{
		isDead = true;
		transform.eulerAngles = new Vector3(0, 0, 180);		// 참새 회전 
		
		// 참새 위치 계산
		Vector3 pos = transform.position;
		pos.y += 0.5f;	
		
		Instantiate(oops, pos, Quaternion.identity);	// Oops 만들기 
	}
	
	//------------------------------
	// 참새 위치 초기화
	//------------------------------
	void SetPosition ()
	{
		delayTime = 1.0f / frmPerSec;		// 이미지 표시 간격 
		ofsX = 1.0f / frames;				// 표시할 이미지 위치 	
		
		speed = Random.Range(2, 3f);		// 참새의 이동 속도
		float y = Random.Range(1.4f, 3.5f);	// 참새의 높이 
		transform.position = new Vector3(-7, y, 6.5f);
	}	
} // end of class 
