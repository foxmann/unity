using UnityEngine;
using System.Collections;

public class CsSky : MonoBehaviour {

	float speed = 0.02f;

	//-------------------------------
	// 배경화면 스크롤
	//------------------------------
	void Update ()
	{
		float ofs = speed * Time.time;
		transform.renderer.material.mainTextureOffset = new Vector2(ofs, -1);
	}
}
