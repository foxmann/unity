using UnityEngine;
using System.Collections;

public class CsOops : MonoBehaviour {

	//------------------------------
	// Oops 설정
	//------------------------------
	void Start () {
		StartCoroutine("DestroyOops");
	}
	
	//-----------------------------
	// Oops 사리지기 
	//-----------------------------
	IEnumerator DestroyOops() {
		yield return new WaitForSeconds(0.5f);	
		
		for (float alpha = 1; alpha >= 0; alpha -= 0.03f) {
			transform.renderer.material.color = new Vector4(1, 1, 1, alpha);
			
			yield return new WaitForFixedUpdate();
		}
		Destroy(gameObject);
	}
}
