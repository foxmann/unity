using UnityEngine;
using System.Collections;

public class CsFireLine : MonoBehaviour {

	float speed = 60f;		// 속도 
	float delay = 1f;		// 오브젝트 삭제 시간(초) 
	
	//-------------------------------
	// 게임 실행 시 제거 시간 설정 
	//------------------------------
	void Start () {
		Destroy(gameObject, delay);	
	}
	
	//-------------------------------
	// 게임 루프 - 실탄 이동
	//------------------------------
	void Update ()
	{
		float amtMove = speed * Time.deltaTime;
		
		// 실탄 이동 
		transform.Translate(Vector3.forward * amtMove);
	}
} // end of class 
