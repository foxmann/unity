using UnityEngine;
using System.Collections;

public class CsBullet : MonoBehaviour {
	
	int speed = 5;					// 우주선의 이동 속도 
	
	//--------------------------
	// Game Loop
	//--------------------------
	void Update () {
		// 포탄의 위치 
		Vector3 pos = transform.position;
		
		// 포탄의 위치를 우주선의 반대 방향으로 이동 
		pos.x -= speed * CsShip.dir.x * Time.smoothDeltaTime;
		pos.z -= speed * CsShip.dir.y * Time.smoothDeltaTime;
		
		transform.position = pos;
		
		// 화면을 벗어난 포탄 제거 
		if (Mathf.Abs(pos.x) > 10 || Mathf.Abs(pos.z) > 6) {
			Destroy (gameObject);	
		}
	}
}
