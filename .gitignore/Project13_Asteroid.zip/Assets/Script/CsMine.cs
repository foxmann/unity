﻿using UnityEngine;
using System.Collections;

public class CsMine : MonoBehaviour {
	
	public Transform expSmall;		// 폭파 불꽃 작은 것 
	public AudioClip sndMine;		// 기뢰 폭파 사운드 
	public Transform bullet;		// 포탄 - 프리팹
	
	Transform ship;					// 우주선
	
	float speed;					// 속도 
	Vector3 dir = Vector3.zero;		// 이동 방향 
	
	int power = 200;				// 포탄의 발사 파워 
	
	//--------------------------
	// 게임 초기화 
	//--------------------------
	void Start () {
		ship = GameObject.Find("우주선").transform;
		
		speed = Random.Range(2.5f, 4);
	}
	
	//--------------------------
	// Game Loop
	//--------------------------
	void Update () {
		// 우주선 방향으로 회전 
		transform.LookAt(ship);
		
		// 이동 
		dir.x = -speed * CsShip.dir.x;
		dir.z = -speed * CsShip.dir.y;
		transform.Translate(dir * Time.smoothDeltaTime, Space.World);

		// 포탄 발사 
		if (Random.Range (0, 1000) > 995) {
			Transform obj = Instantiate (bullet, transform.position, transform.rotation) as Transform;
			obj.rigidbody.AddForce(transform.forward * power);
		}
		
		// 화면을 벗어난 기뢰 제거 
		Vector3 pos = transform.position;
		if (Mathf.Abs(pos.x) > 12 || Mathf.Abs(pos.z) > 8) {
			Destroy (gameObject);	
		}
	}
	
	//--------------------------
	// 기뢰 파괴 - 외부 호출
	//--------------------------
	void DestroySelf () {
		AudioSource.PlayClipAtPoint(sndMine, transform.position);
		Instantiate(expSmall, transform.position, Quaternion.identity);
		
		CsManager.mineCnt++;
		CsManager.score += 1000;
		
		Destroy(gameObject);
	}
}

