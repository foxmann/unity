using UnityEngine;
using System.Collections;

public class CsSkyFar : MonoBehaviour {
	
	float speed = 0.0005f;
	
	//--------------------------
	// Game Loop
	//--------------------------
	void Update () {
		// 매트리얼의 텍스처 Offset 
		Vector2 ofs = transform.renderer.material.mainTextureOffset;

		// 이동할 거리 계산 
		float x = CsShip.dir.x * speed;
		float y = CsShip.dir.y * speed;
			
		// Offset 이동 
		ofs.x += x;
		ofs.y += y;
		
		transform.renderer.material.mainTextureOffset = ofs;
	}
}
