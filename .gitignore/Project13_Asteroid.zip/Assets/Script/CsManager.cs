﻿using UnityEngine;
using System.Collections;

public class CsManager : MonoBehaviour {
	
	public GUISkin skin;		// GUI Skin
	
	// Object 관련 
	public Transform enemy;		// 적기 
	
	Transform ship;				// 우주선 
	Transform startStation;		// 출발지  
	Transform destStation;		// 목적지 
	Transform planet;			// 행성 
	GameObject fade;			// fadein / fadeout용 plane 
	
	// GUIText
	GUIText txtMsg;				// 메시지 표시 
	GUIText txtStage;			// 스테이지 
	GUIText txtEnemy;			// 파괴한 적기 수 
	GUIText txtMine;			// 파괴한 기뢰 수 
	GUIText txtAster;			// 파괴한 운석 수 
	GUIText txtBonus;			// 획득한 Bonus 아이템 수 
	GUIText txtScore;			// 점수 
	GUIText txtDistX;			// 목적지까지 남은 거리 
	GUIText txtDistY;			// 목적지까지 남은 거리 

	// 게임 상태 관련 
	public enum STATE {
			START, 				// 스테이지 시작 
			CLEAR, 				// 스테이지 클리어 
			OVER, 				// 게임 오버 
			ENEMY, 				// 적기 등장 
			COMBAT, 			// 적기와 전투중
			BONUS, 				// Bonus 아이템 획득
			HIT, 				// 운석 또는 기뢰 파괴함 
			DESTROY, 			// 적기 파괴함 
			LOST,				// 우주선을 잃음 
			WORK, 				// 작업중 - 다른 프로세스 진행
			WAIT, 				// 작업중 - 다른 프로세스 중지
			IDLE 				// 대기중 
	}
	
	static public STATE state = STATE.START;
	static public STATE lastState = state;	// 직전의 상태 
	
	// 스테이지 관련 
	int stageCnt = 10;				// 스테이지 수 
	int stageNum = 1;				// 스테이지 번호 
	
	// 출발지로부터 목적지까지의 거리 
	int[] targetX = {320, -280, 330, 270, -350, -330, 340, 350, -350, -300};
	int[] targetY = {-280, -320, 290, -350, 300, -240, -290, -320, -280, 290};
	
	Vector2 dist;						// 목적지까지 남은 거리 
	
	// 점수 관련   
	static public int score = 0;		// 점수 
	static public int enemyCnt = 0;		// 파괴한 적기 수 
	static public int mineCnt = 0;		// 파괴한 기뢰 수 
	static public int asterCnt = 0;		// 파괴한 운석 수 
	static public int bonusNum = 0;		// 현재의 Bonus 아이템 번호 
	
	int bonusCnt = 0;					// 획득한 Bonus 아이템 수 
	int shipCnt = 5;					// 남은 우주선 수 
	
	bool hasEnemy = false;				// 적기 출현 여부 
	
	//--------------------------
	// 게임 초기화 
	//--------------------------
	void Start () {
		// Object 찾기 
		ship = GameObject.Find("우주선").transform;
		startStation = GameObject.Find("출발지").transform;
		destStation = GameObject.Find("목적지").transform;
		planet = GameObject.Find("행성").transform;
		fade = GameObject.Find("Fade");
		
		// GUIText 찾기 
		txtMsg = GameObject.Find("0txtMsg").guiText;
		txtStage = GameObject.Find("1txtStage").guiText;
		txtEnemy = GameObject.Find("2txtEnemy").guiText;
		txtMine = GameObject.Find("3txtMine").guiText;
		txtAster = GameObject.Find("4txtAster").guiText;
		txtBonus = GameObject.Find("5txtBonus").guiText;
		txtScore = GameObject.Find("6txtScore").guiText;
		txtDistX = GameObject.Find("7txtDistX").guiText;
		txtDistY = GameObject.Find("8txtDistY").guiText;
		
		// static 변수 초기화 
		state = STATE.START;
		score = 0;		
		enemyCnt = 0;	
		mineCnt = 0;	
		asterCnt = 0;	
		bonusNum = 0;	
	}
	
	//--------------------------
	// 게임 루프 
	//--------------------------
	void Update () {
		switch (state) {
		case STATE.START :
			StartCoroutine("MakeStage");
			break;
		case STATE.CLEAR :
			StartCoroutine("StageClear");
			break;
		case STATE.BONUS :	
			ProcessBonus();
			break;
		case STATE.ENEMY :	
			EnterEnemy();
			break;
		case STATE.DESTROY :	
			DestroyEnemy();
			break;
		case STATE.LOST :	
			StartCoroutine("LostShip");
			break;
		}
		
		CalcDistance();
		
		if (Input.GetKeyDown(KeyCode.Escape)) {
			Application.LoadLevel("GameTitle");	
		}
	}
	
	//--------------------------
	// 게임 스테이지 만들기 
	//--------------------------
	IEnumerator MakeStage () {
		state = STATE.WAIT;
		
		// 출발지 
		Vector3 pos = new Vector3(0, -3, 0);
		startStation.position = pos;
		
		// 목적지 
		pos.x = targetX[stageNum - 1];
		pos.z = targetY[stageNum - 1];
		destStation.position = pos;
		
		// 우주선을 목적지 방향으로 회전 
		pos.y = 0;
		// ship.rotation = Quaternion.LookRotation(pos);
		ship.LookAt(pos);
		
		// 출발지와 목적지를 교대로 표시 
		Texture2D img1 = Resources.Load("imgStart") as Texture2D;
		Texture2D img2 = Resources.Load("imgTarget") as Texture2D;
		
		if (stageNum % 2 == 1) {
			startStation.renderer.material.mainTexture = img1;	
			destStation.renderer.material.mainTexture = img2;	
		} else {
			startStation.renderer.material.mainTexture = img2;	
			destStation.renderer.material.mainTexture = img1;	
		}
		
		// 마지막 스테이지의 목적지는 최종 목적지인 행성의 이미지 
		if (stageNum == stageCnt) {
			Texture2D imgGoal = Resources.Load("imgPlanet") as Texture2D;
			destStation.renderer.material.mainTexture = imgGoal;	
		}
		
		// 스테이지의 행성 이미지 
		Texture2D imgPlanet = Resources.Load("imgPlanet" + stageNum) as Texture2D;
		planet.renderer.material.mainTexture = imgPlanet;
		
		// 행성의 위치는 목적지의 1/5
		pos = destStation.position * 0.2f;
		pos.y = -5;
		planet.position = pos;
		
		// 화면 갱신까지 대기 
		yield return new WaitForFixedUpdate();
		
		// 스테이지 번호 표시 
		StartCoroutine("ShowStageNum");
		StartCoroutine("FadeIn", true);
		
		yield return new WaitForSeconds(1.5f);
		fade.SetActive(false);
		
		state = STATE.IDLE;
	}

	//--------------------------
	// 스테이지 CLEAR 
	//--------------------------
	IEnumerator StageClear () {
		state = STATE.WAIT;
		
		StartCoroutine("FadeIn", false); 		// 화면 Fade-out 
		yield return new WaitForSeconds(2f);	// 2초간 대기 

		score += 50000;							// 득점 처리 
		stageNum++;
		if (stageNum > stageCnt) {				// 마지막 스테이지가 끝나면 
			Application.LoadLevel("GameTitle");	// GameTitle 호출 
		}
		
		hasEnemy = false;
		state = STATE.START;
	}
	
	//--------------------------
	// 스테이지 시작 시 스테이지 번호 
	//--------------------------
	IEnumerator ShowStageNum () {
		txtMsg.text = "STAGE " + stageNum;
		txtMsg.material.color = new Vector4(0, 1, 0.5f, 1);
		
		// 글자 크기 설정
		for (int i = 1; i <= 160; i += 2) {
			txtMsg.fontSize = i;	
			
			yield return new WaitForFixedUpdate();
		}
		
		// 글자 투명도 설정 
		for (float a = 1; a >= 0; a -= 0.02f) {
			txtMsg.material.color = new Vector4(0, 1, 0.5f, a);				
			
			yield return new WaitForFixedUpdate();
		}
	}
	
	//--------------------------
	// Fade-in / Fade-out 
	//--------------------------
	IEnumerator FadeIn(bool flag) {
		fade.SetActive(true);
		Color color = fade.renderer.material.color;
		
		for (float a = 1; a >= 0; a -= 0.01f) {
			if (flag) {
				color.a = a;
			} else {
				color.a = 1 - a;
			}
			
			fade.renderer.material.color = color;
			yield return new WaitForFixedUpdate();
		}
	}
	
	//--------------------------
	// Bonus Item 처리 
	//--------------------------
	void ProcessBonus() {
		state = lastState;
		bonusCnt++;
		
		switch (bonusNum) {
		case 1 :					// 모든 운석 제거 
			StartCoroutine("DeleteAsteroids");
			break;
		case 2 :					// 모든 기뢰 제거 
			StartCoroutine("DeleteMines");
			break;
		case 3 :					// 10초간 우주선 무적 상태
			ship.SendMessage("UndeadShip", 10, SendMessageOptions.DontRequireReceiver);
			break;
		case 4 :					// 우주선 보호막 충전
			CsShip.shield = (int) Mathf.Clamp(CsShip.shield + 5, 0, 10);
			break;
		case 5 :					// 남은 우주선 수 증가 
			shipCnt = (int) Mathf.Clamp(shipCnt + 1, 0, 5);
			break;
		}
	}

	//--------------------------
	// 모든 운석 제거 - Bonus 처리용 
	//--------------------------
	IEnumerator DeleteAsteroids() {
		// 모든 운석 찾기 
		GameObject[] obj = GameObject.FindGameObjectsWithTag("ASTEROID");
		
		foreach (GameObject tmp in obj) {
			if (tmp != null) {
				tmp.SendMessage("DestroySelf", SendMessageOptions.DontRequireReceiver);
				yield return new WaitForSeconds(0.1f);
			}	
		}
	}
	
	//--------------------------
	// 모든 기뢰 제거 - Bonus 처리용 
	//--------------------------
	IEnumerator DeleteMines() {
		// 모든 기뢰 찾기 
		GameObject[] obj1 = GameObject.FindGameObjectsWithTag("MINE");
		
		foreach (GameObject tmp in obj1) {
			if (tmp != null) {
				tmp.SendMessage("DestroySelf", SendMessageOptions.DontRequireReceiver);
				yield return new WaitForSeconds(0.1f);
			}	
		}
		
		// 모든 포탄 찾기 
		GameObject[] obj2 = GameObject.FindGameObjectsWithTag("BULLET");
		foreach (GameObject tmp in obj2) {
			if (tmp != null) {
				Destroy(tmp);
			}	
		}
	}
	
	//--------------------------
	// 적기 등장
	//--------------------------
	void EnterEnemy () {
		state = STATE.COMBAT;		// 전투 모드 설정
		
		Instantiate(enemy, new Vector3(0, 0, 10), Quaternion.identity);
		
		// 우주선을 전투 모드로 전환 
		ship.SendMessage("EnterCombat", SendMessageOptions.DontRequireReceiver);
	}
	
	//--------------------------
	// 적기 파괴 후의 처리 
	//--------------------------
	void DestroyEnemy () {
		state = STATE.WORK;			// 작업 모드 설정
		enemyCnt++;					// 파괴한 적기 수 
		score += 500000;			// 득점
		
		// 우주선을 운행 모드로 전환 
		ship.SendMessage("EnterMove", SendMessageOptions.DontRequireReceiver);
	}
	
	//--------------------------
	// 우주선을 잃음
	//--------------------------
	IEnumerator LostShip() {
		state = STATE.WAIT;
		
		shipCnt--;
		if (shipCnt < 0) {
			Application.LoadLevel("GameTitle");
			yield break;
		}
		
		yield return new WaitForSeconds(2);
		
		// 우주선을 보이는 위치로 이동 
		Vector3 pos = ship.position;
		pos.y = 0;
		ship.position = pos;
		
		// 우주선의 보호막 충전
		CsShip.shield = 10;		
		// 5초간 무적상태 유지 
		ship.SendMessage("UndeadShip", 5, SendMessageOptions.DontRequireReceiver);
		
		state = STATE.IDLE;
	}
		
	//--------------------------
	// 남은 거리 계산 
	//--------------------------
	void CalcDistance () {
		if (state == STATE.WAIT) return;
		
		dist.x = destStation.position.x;		
		dist.y = destStation.position.z;	
		
		// ±2 범위이면 목적지에 도착한 것으로 처리 
		if (Mathf.Abs(dist.x) < 2 && Mathf.Abs(dist.y) < 2) {
			state = STATE.CLEAR;	
		}
		
		// 적기가 출현했는가?
		if (hasEnemy) return;
		
		// 목적지의 1/3 계산 
		float x = Mathf.Abs(targetX[stageNum - 1]) / 3;
		float y = Mathf.Abs(targetY[stageNum - 1]) / 3;
		
		if (Mathf.Abs(dist.x) < x && Mathf.Abs(dist.y) < y) {
			state = STATE.ENEMY;	
			hasEnemy = true;
		}
	}	

	//--------------------------
	// GUI
	//--------------------------
	void OnGUI () {
		// GUI.skin = skin;
		
		DisplayScore();
		DisplayMinimap();
	}
	
	//--------------------------
	// 점수 표시 
	//--------------------------
	void DisplayScore () {
		txtStage.text = "Stage  " + stageNum;
		txtEnemy.text = "Enemy  " + enemyCnt;
		txtMine.text =  "Mine     " + mineCnt;  
		txtAster.text = "Aster  " + asterCnt;
		txtBonus.text = "Bonus  " + bonusCnt;
		txtScore.text = "Score  " + score;
		txtDistX.text = "Dist_X " + (int) Mathf.Abs(dist.x * 10);
		txtDistY.text = "Dist_Y " + (int) Mathf.Abs(dist.y * 10);

		// 보호막 표시  
		float px = Screen.width * 0.8f + 50;
		float py = Screen.height * 0.858f;
		for (int i = 1; i < CsShip.shield; i++) {
			GUI.DrawTexture(new Rect(px + i * 8, py, 6, 10), 
								Resources.Load("imgShield") as Texture2D);
		}
		
		// 남은 우주선 수 표시 
		float sx = Screen.width * 0.8f;
		float y = Screen.height * 0.9f;
		for (int i = 0; i < shipCnt; i++) {
			float x = sx + i * 26;
			GUI.DrawTexture(new Rect(x, y, 26, 26), Resources.Load("miniship") as Texture2D);
		}
	}

	//--------------------------
	// 미니맵 표시 
	//--------------------------
	void DisplayMinimap () { 
		// 미니맵의 시작 위치
		float mx = Screen.width * 0.8f;
		float my = Screen.height * 0.58f;
		
		// 맵의 크기 
		float mw = Screen.width * 0.18f;
		float mh = Screen.width * 0.12f;
		
		// 맵의 중앙 좌표 
		float cx = mx + mw / 2;
		float cy = my + mh / 2;
		
		// 목적지의 방향 
		int dx = (targetX[stageNum - 1] > 0) ? -1 : 1;
		int dy = (targetY[stageNum - 1] > 0) ? 1 : -1;
		
		// 출발지 위치
		float sx = cx + mw / 2 * dx; 
		float sy = cy + mh / 2 * dy;
		
		// 목적지 위치
		float tx = cx - mw / 2 * dx;
		float ty = cy - mh / 2 * dy;
		
		// 맵 영역 
		Rect mRect = new Rect(mx - 3, my - 3, mw + 6, mh + 6);
		GUI.Box(mRect, "");
		
		// 출발지와 목적지 
		GUI.DrawTexture(new Rect(sx - 3, sy - 3, 6, 6), Resources.Load("mapStart") as Texture2D);
		GUI.DrawTexture(new Rect(tx - 3, ty - 3, 6, 6), Resources.Load("mapTarget") as Texture2D);
		
		// 픽셀당 거리 
		float px = mw / targetX[stageNum - 1];
		float py = mh / targetY[stageNum - 1];
		
		// 현재 위치 
		float x = tx + dist.x * px * dx;
		float y = ty + dist.y * py * dy;
		
		// 맵 범위 이내로 제한
		x = Mathf.Clamp(x, mx, mx + mw);
		y = Mathf.Clamp(y, my, my + mh);
		GUI.DrawTexture(new Rect(x - 3, y - 3, 6, 6), Resources.Load("mapPos") as Texture2D);
	}
}
