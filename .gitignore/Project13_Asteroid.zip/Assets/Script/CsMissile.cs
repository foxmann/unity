using UnityEngine;
using System.Collections;

public class CsMissile : MonoBehaviour {
	
	int speed = 3;

	//--------------------------
	// Game 초기화 
	//--------------------------
	void Start () {
		Destroy (gameObject, 4);	// 4초 후에 제거 	
	}
	
	//--------------------------
	// Game Loop
	//--------------------------
	void Update () {
		float amtMove = speed * Time.smoothDeltaTime;
		transform.Translate(Vector3.forward * amtMove);
	}
	
	//--------------------------
	// 충돌 판정 
	//--------------------------
	void OnTriggerEnter (Collider coll) {
		
	}
}

