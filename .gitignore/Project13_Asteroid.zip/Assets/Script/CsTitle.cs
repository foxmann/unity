﻿using UnityEngine;
using System.Collections;
using System.Text;

public class CsTitle : MonoBehaviour {
	
	public GUISkin skin;
	
	bool isAbout = false;
	bool isHelp = false;
	
	Vector2 scrollPosition;
	
	//--------------------------
	// On GUI
	//--------------------------
	void OnGUI () {
		GUI.skin = skin;
		
		// 화면의 폭 
		int w = Screen.width;
		int h = Screen.height;
		
		// 배경 그리기 
		GUI.DrawTexture(new Rect(0, 0, w, h), Resources.Load("imgTitle") as Texture2D);
		
		// About
		if (isAbout) {
			DisplayAbout();	
			return;
		}
		
		// Help
		if (isHelp) {
			DisplayHelp();	
			return;
		}
		
		// Box 그리기 		
		float bw = w * 0.5f;
		float bh = h * 0.8f;
		
		GUI.Box(new Rect(w * 0.25f, h * 0.2f, bw, bh), "");
		
		// Button 그리기 
		float bx = w / 2 - 120;
		
		// New Game
		if (GUI.Button(new Rect(bx, h * 0.3f, 240, 80), "New Game")) {
			Application.LoadLevel("MainGame");
		}
		
		// About
		if (GUI.Button(new Rect(bx, h * 0.45f, 240, 80), "About Game")) {
			isAbout = true;	
		}
		
		// Help
		if (GUI.Button(new Rect(bx, h * 0.6f, 240, 80), "Help Game")) {
			isHelp = true;
		}
		
		// Quit
		if (GUI.Button(new Rect(bx, h * 0.75f, 240, 80), "Quit Game")) {
			Application.Quit();
		}
	}
	
	//--------------------------
	// About
	//--------------------------
	void DisplayAbout () {
		StringBuilder buf = new StringBuilder();
		
		buf.Append("이 게임은 도서 출판 jpup에서 발행한 ");
		buf.Append("'UNITY3D 입문과 완성'의 ");
		buf.Append("예제로 작성한 것입니다. ");
		
		buf.Append("이 프로그램에 대한 저작권은 필자에게 있으나 ");
		buf.Append("이 책의 독자들은 필자의 동의없이 "); 
		buf.Append("임의로 프로그램을 변경하고 배포할 수 ");
		buf.Append("있습니다.");
		
		int w = Screen.width;
		int h = Screen.height;						
		
		// Window 크기 
		float winW = w * 0.6f;			
		float winH = h * 0.7f;	
		
		Rect rect = new Rect(w * 0.2f, h * 0.2f, winW, winH);
		GUI.Window(0, rect, WindowFunc, "About");
		
		// 문자열 출력 
		GUI.Label(new Rect(w * 0.25f, h * 0.3f, w * 0.5f, h * 0.6f), buf.ToString());
		
		// Back Button
		if (GUI.Button(new Rect(w / 2 - 70, h * 0.7f, 140, 50), "Back")) {
			isAbout = false;	
		}
	}
	
	//-----------------------------
	// Help
	//-----------------------------
	void DisplayHelp() {
		int w = Screen.width;
		int h = Screen.height;						
		float winW = 360;			// Window 크기
		float winH = 240;	
	
		// Window 그리기
		Rect winRect = new Rect((w - winW) / 2, (h - winH) / 2 + 10, winW, winH);
		GUI.Window(0, winRect, WindowFunc, "Help");

		// 스크롤뷰의 표시 영역
		Rect scrollRect = new Rect((w - winW) / 2 + 50, (h - winH) / 2 + 40, winW - 60, winH - 40);	

		// 화면에 표시할 작업 영역
		Rect scrollArea = new Rect(0 ,0, winW - 80, 410);
		
		scrollPosition = GUI.BeginScrollView(scrollRect, scrollPosition, scrollArea);
			GUI.Label(new Rect(0, 0, 120, 30), "Drive Mode");
			GUI.Label(new Rect(30, 25, 120, 30), "[←] : Trun Left");
			GUI.Label(new Rect(30, 50, 120, 30), "[→] : Turn Right");
			GUI.Label(new Rect(30, 75, 120, 30), "[Ctrl] : Fire");
		
			GUI.Label(new Rect(0, 100, 120, 30), "Combat Mode");
			GUI.Label(new Rect(30, 125, 120, 30), "[←] : Move Left");
			GUI.Label(new Rect(30, 150, 120, 30), "[→] : Move Right");
			GUI.Label(new Rect(30, 175, 120, 30), "[Ctrl] : Fire");
		
			GUI.Label(new Rect(0, 200, 220, 30), "Bonus Item");
			GUI.Label(new Rect(30, 225, 220, 30), "Yellow : Destroy All Asteroids");
			GUI.Label(new Rect(30, 250, 220, 30), "Green : Destroy All Mines");
			GUI.Label(new Rect(30, 275, 220, 30), "Blue : Undead Ship 10 Seconds");
			GUI.Label(new Rect(30, 300, 220, 30), "Yellow : Increase Shield +5");
			GUI.Label(new Rect(30, 325, 220, 30), "Cyan : Increase Ship Count +1");
		
			// Go Back
			if (GUI.Button(new Rect(60, 370, 140, 50), "Go back")) {
				isHelp = false;
			}
		GUI.EndScrollView();	
	}
		
	//-----------------------------
	// GUI Window 처리 함수
	//-----------------------------
	void WindowFunc (int winID) {
		// do nothing
	}	
}
	
