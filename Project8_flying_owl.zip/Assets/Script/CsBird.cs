using UnityEngine;
using System.Collections;

public class CsBird : MonoBehaviour {
	
	public Transform txtScore;	// 프리팹 
	
	int frmCnt = 6; 			// 전체 프레임 수 
	int frmPerSec;				// 1초에 표시할 프레임 수 
	float frmDelay;				// 프레임 표시 간격 
	int frmNum = 0; 			// 현재 표시할 프레임 번호 
	
	int speed;					// 이동 속도 
	bool isDrop = false;		// 추락중인가? 

	//-------------------
	// 속도 및 애니메이션 설정  
	//-------------------
	void Start () {
		speed = Random.Range(3, 7);	
		
		frmPerSec = Random.Range(10, 18);	
		frmDelay = 1.0f / frmPerSec;		
	}
	
	//-------------------
	// 게임 루프
	//-------------------
	void Update () {
		float amtMove = speed * Time.smoothDeltaTime;
		
		if (!isDrop) {
			AnimateBird();
			transform.Translate(Vector3.right * amtMove);
		} else {			// 아래로 이동 
			transform.Translate(Vector3.down * amtMove, Space.World);
		}	
		
		// 화면을 벗어난 오브젝트 제거 
		Vector3 view = Camera.main.WorldToScreenPoint(transform.position);
		if (view.y < -50 || view.x > Screen.width + 50) {
			Destroy(gameObject);
		}	
	}
	
	//-------------------
	// 애니메이션 
	//-------------------
	void AnimateBird () {
		frmDelay -= Time.deltaTime;
		
		if (frmDelay > 0) return;
		
		frmNum = (int) Mathf.Repeat(++frmNum, frmCnt);	
		float ofsX = 1.0f / frmCnt * frmNum;
			
		transform.renderer.material.mainTextureOffset = new Vector2(ofsX, 0);
		frmDelay = 1.0f / frmPerSec;
	}
	
	//-------------------
	// 충돌 처리 - 외부 호출
	//-------------------
	void DropBird () {
		isDrop = true;
		
		// 참새 회전 
		transform.eulerAngles = new Vector3(0, 0, 180);
			
		// 감점 표시 
		Transform obj = Instantiate(txtScore) as Transform;
		obj.guiText.text = "<color=red><size=22>-1000</size></color>";
		
		// World 좌표를 Viewport 좌표로 변환 
		var pos = Camera.main.WorldToViewportPoint(transform.position);
		obj.position = pos;
	}
} // end of class
