using UnityEngine;
using System.Collections;

public class CsScore : MonoBehaviour {

	//-------------------
	// 게임 초기화 
	//-------------------
	void Start () {
		StartCoroutine("DisplayScore");
	}
	
	//-------------------
	// 게임 루프 
	//-------------------
	void Update () {
		Vector3 pos = transform.position;
		pos.y += 0.001f;
		transform.position = pos;
	}
	
	//-------------------
	// 점수를 투명하게 처리 
	//-------------------
	IEnumerator DisplayScore() {
		yield return new WaitForSeconds(0.5f);
		
		for (float a = 1; a >= 0; a -= 0.05f) {
			transform.guiText.material.color = new Vector4(1, 1, 1, a);
			yield return new WaitForFixedUpdate();
		}
		
		Destroy(gameObject);
	}
}
