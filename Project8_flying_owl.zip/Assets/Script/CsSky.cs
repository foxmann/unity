using UnityEngine;
using System.Collections;

public class CsSky : MonoBehaviour {
	
	float speed = 0.03f;
	
	//------------------------------
	// 화면 스크롤
	//------------------------------
	void Update ()
	{
		float ofsX = speed * Time.time;
		transform.renderer.material.mainTextureOffset = new Vector2(ofsX, 0);
	}
} // end of class 
