﻿using UnityEngine;
using System.Collections;

public class CsOwl : MonoBehaviour {
	
	public GUISkin skin;			// GUI Skin
	
	public Transform branch;		// 프리팹 
	public Transform gift;
	public Transform bird;
	
	public AudioClip sndJump;		// 효과음 및 배경음악 
	public AudioClip sndGift;
	public AudioClip sndBird;
	public AudioClip sndStage;
	public AudioClip sndOver;
	
	Transform spPoint;				// Spawn Point
	Transform newBranch;			// 새로만들 나뭇가지 
	
	int speedSide = 10;				// 좌우 이동 속도 
	int speedJump = 16;				// 점프 속도 
	int gravity = 25;				// 추락 속도 

	Vector3 moveDir = Vector3.zero;	// 올빼미의 이동 방향 
	
	int giftCnt = 0;				// 획득한 선물 수 
	float score = 0;				// 득점 
	float maxY = 0;					// 올빼미의 최대 높이 
	
	bool isDead = false;			// 올빼미 추락?
	
	//-------------------
	// 게임 초기화
	//-------------------
	void Start () {
		// 모바일 단말기 설정
		Screen.orientation = ScreenOrientation.LandscapeRight;
		Screen.sleepTimeout = SleepTimeout.NeverSleep;

		spPoint = GameObject.Find("spPoint").transform;
		
		// 나뭇가지 만들기 
		newBranch = Instantiate(branch, spPoint.position, spPoint.rotation) as Transform;
		
		Screen.showCursor = false;		// 커서 감추기 
	}
	
	//-------------------
	// 게임 루프
	//-------------------
	void Update () {
		if (isDead) return;
		
		JumpOwl();			// 올빼미 점프
		MoveOwl();			// 올빼미 이동 
		MoveCamera();		// 카메라 이동 
		MakeGift();			// 선물과 새 만들기 
	}
	
	//-------------------
	// 올빼미 점프
	//-------------------
	void JumpOwl () {
		RaycastHit hit;
		
		// 올빼미 아래에 나뭇가지가 있는지 조사
		if (Physics.Raycast(transform.position, Vector3.down, out hit, 0.9f)) {
			if (hit.transform.tag == "BRANCH") {
				moveDir.y = speedJump;
				AudioSource.PlayClipAtPoint(sndJump, transform.position);
			}
		}
	}

	//-------------------
	// 올빼미 이동
	//-------------------
	void MoveOwl () {
		// 올빼미 위치를 Screen 좌표로 변환 
		Vector3 view = Camera.main.WorldToScreenPoint(transform.position);
		
		if (view.y < -50) {		// 화면 아래를 벗어나면  
			isDead = true;		// 게임 오버 
			return;			
		}	
		
		moveDir.x = 0;		// 올빼미의 좌우 이동 방향
		
		// Mobile 처리 
		if (Application.platform == RuntimePlatform.Android || 
			Application.platform == RuntimePlatform.IPhonePlayer) {
			// 중력 가속도 센서 읽기 
			float x = Input.acceleration.x;
			
			// 왼쪽으로 기울였나?
			if (x < -0.2f && view.x > 35) {
				moveDir.x = 2 * x * speedSide;
			}
			
			if (x > 0.2f && view.x < Screen.width - 35) {
				moveDir.x = 2 * x * speedSide;
			}	
			
		} else {	// Keyboard 읽기 
			float key = Input.GetAxis("Horizontal");	
			if ((key < 0 && view.x > 35) ||		
			    (key > 0 && view.x < Screen.width - 35)) {
				moveDir.x = key * speedSide;
			}	
		}
		
		// 매 프레임마다 점프 속도 감소
		moveDir.y -= gravity * Time.deltaTime;
		transform.Translate(moveDir * Time.smoothDeltaTime);
		
		// 올빼미의 날개  
		int n = 2;					// 날개 펴기 
		if (moveDir.y < 0) n = 1;	// 날개 접기 
		
		transform.renderer.material.mainTexture = Resources.Load("owl" + n) as Texture2D;
	}
	
	//-------------------
	// 카메라 이동
	//-------------------
	void MoveCamera () {
		// 올빼미의 최대 높이 구하기 
		if (transform.position.y > maxY) {
			maxY = transform.position.y;
			
			// 카메라 위치 이동 
			Camera.main.transform.position = new Vector3(0, maxY - 2.5f, -10);
			score = maxY * 1000;
		}
		
		// 가장 최근의 나뭇가지와 spPoint와의 거리 구하기
		if (spPoint.position.y - newBranch.position.y >= 4) {
			float x = Random.Range(-10f, 10f) * 0.5f;
			Vector3 pos = new Vector3(x, spPoint.position.y, 0.3f);
			newBranch = Instantiate(branch, pos, Quaternion.identity) as Transform;	
			
			// 나뭇가지의 회전방향 설정 
			int mx = (Random.Range(0, 2) == 0) ? -1 : 1;
			int my = (Random.Range(0, 2) == 0) ? -1 : 1;
			newBranch.renderer.material.mainTextureScale = new Vector2(mx, my);
		}	
	}
	
	//-------------------
	// 선물 및 참새 만들기
	//-------------------
	void MakeGift () {
		if (Random.Range(1, 1000) < 980) return;
		
		// 오브젝트 표시 위치 
		Vector3 pos = Vector3.zero;
		pos.y = maxY + Random.Range(4, 5.5f);	
		
		if (Random.Range(0, 100) < 50) {
			// 참새 만들기 
			pos.x = -12f;
			Instantiate(bird, pos, Quaternion.identity);
		} else {	
			// 화면의 선물 수를 5개 이내로 제한 
			int n1 = GameObject.FindGameObjectsWithTag("GIFT1").Length;
			int n2 = GameObject.FindGameObjectsWithTag("GIFT2").Length;
			int n3 = GameObject.FindGameObjectsWithTag("GIFT3").Length;
			
			if (n1 + n2 + n3 >= 5) return;
			
			// 선물 만들기 
			pos.x = Random.Range(-5f, 5f);
			Transform obj = Instantiate(gift, pos, Quaternion.identity) as Transform;
			
			int n = Random.Range(1, 4);
			obj.tag = "GIFT" + n;
				
			// Gift의 이미지 설정 
			obj.gameObject.renderer.material.mainTexture = Resources.Load("gift" + n) as Texture2D;
		}	
	}
	
	//-------------------
	// 충돌 처리
	//-------------------
	void OnTriggerEnter (Collider coll) {
		switch (coll.transform.tag.Substring(0, 4)) {
		case "GIFT" :
			AudioSource.PlayClipAtPoint(sndGift, transform.position);
			// 득점 처리 
			int n = int.Parse(coll.transform.tag.Substring(4));
			score += n * 500;
			giftCnt++;
				
			// 선물 제거 
			coll.transform.SendMessage("DisplayScore", SendMessageOptions.DontRequireReceiver);
			break;
		case "BIRD" :
			if (coll.transform.eulerAngles.z != 0) return;
			
			AudioSource.PlayClipAtPoint(sndBird, transform.position);
			score -= 1000;
			
			// 참새 추락 처리 
			coll.transform.SendMessage("DropBird", SendMessageOptions.DontRequireReceiver);
			break;
		}
	}
	
	//-------------------
	// 화면 표시 
	//-------------------
	void OnGUI() {
		
		GUI.skin = skin;
		
		string tScore = "<size='28'><color='navy'>Score : ##</color></size>";
		string tHeight = "<size='28'><color='navy'>Height : ##</color></size>";
		string tGift = "<size='28'><color='navy'>Gift : ##</color></size>";

		tScore = tScore.Replace("##", "" + (int)score);
		tHeight = tHeight.Replace("##", "" + (int)maxY);
		tGift = tGift.Replace("##", "" + giftCnt);  	
		
		int w = Screen.width / 2;
		int h = Screen.height / 2;
		
		GUI.Label(new Rect(20, 30, 200, 80), tScore);
		GUI.Label(new Rect(w - 50, 30, 150, 80), tHeight);
		GUI.Label(new Rect(w * 1.5f, 30, 120, 80), tGift);
		
		if (!isDead) return;
		
		Screen.showCursor = true;		// 커서 보이기 
		// 배경 음악 바꾸기 
		if (audio.clip != sndOver) {
			audio.clip = sndOver;
			audio.loop = false;
			audio.Play();
		}	
		
		if (GUI.Button(new Rect(w - 70, h - 50, 140, 60), "Play Game")) {
			Application.LoadLevel("MainGame");
		}	
		
		if (GUI.Button(new Rect(w - 70, h + 50, 140, 60), "Quit Game")) {
			Application.Quit();
		}	
	}
} // end of class
